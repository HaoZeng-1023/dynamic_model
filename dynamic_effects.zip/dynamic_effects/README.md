# 城市间动态一般均衡模型 (CDGE Model)

## 项目概述
本项目实现了一个求解C个城市加1个外部区域（ROW）的动态经济模型。该模型能够评估政策变化（如基础设施投资导致的贸易成本下降）对各城市经济的动态影响。

## 核心功能
- 求解经济系统的稳态（长期均衡）
- 计算政策冲击后的动态转移路径
- 评估各城市的福利变化

## 模型特点
- 多城市空间一般均衡模型
- 考虑贸易和资本流动的动态调整
- 能够分析政策变化的短期和长期效应

## 项目结构
```
CDGE_Model/
│
├── README.md                      # 项目说明文档
├── setup.m                        # 环境配置脚本
├── run_main.m                     # 主程序入口
│
├── src/                           # 源代码目录
│   ├── core/                      # 核心计算模块
│   ├── utils/                     # 工具函数
│   ├── models/                    # 模型组件
│   └── visualization/             # 可视化模块
│
├── data/                          # 数据目录
│   ├── raw/                       # 原始数据
│   ├── processed/                 # 处理后数据
│   └── config/                    # 配置文件
│
├── tests/                         # 测试目录
│
├── results/                       # 结果输出目录
│
├── docs/                          # 文档目录
│
└── scripts/                       # 脚本目录
```

## 使用方法
1. 运行 `setup.m` 进行环境配置
2. 准备输入数据（城市数据、贸易矩阵、距离矩阵）
3. 设置政策参数（在 `data/config/policy_scenarios/` 目录下）
4. 运行 `run_main.m` 执行分析
5. 查看 `results/` 目录下的分析结果

## 依赖项
- MATLAB R2019b 或更高版本
- Optimization Toolbox
- Statistics and Machine Learning Toolbox

## 参考文献
- Allen, T., & Arkolakis, C. (2014). Trade and the Topography of the Spatial Economy. *Quarterly Journal of Economics*.
- Caliendo, L., Parro, F., Rossi-Hansberg, E., & Sarte, P. D. (2018). The Impact of Regional and Sectoral Productivity Changes on the U.S. Economy. *Review of Economic Studies*. 