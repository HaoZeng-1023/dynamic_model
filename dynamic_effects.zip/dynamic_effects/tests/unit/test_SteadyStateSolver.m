%% 单元测试 - SteadyStateSolver类
% 此脚本测试SteadyStateSolver类的功能

%% 设置测试环境
% 添加项目路径
addpath(genpath('../../src'));

%% 创建测试数据
% 创建模型参数
params = struct();
params.C = 3;           % 测试用小规模城市数量
params.beta = 0.95;     % 折现因子
params.psi = 0.5;       % 跨期替代弹性
params.delta = 0.05;    % 折旧率
params.theta = 5;       % 贸易弹性
params.epsilon = 4;     % 资本替代弹性
params.sigma = params.theta + 1;  % 商品替代弹性

% 创建城市数据
city_data = struct();
city_data.pop = [1; 2; 3];        % 人口
city_data.mu = [0.6; 0.7; 0.8];   % 劳动份额
city_data.GDP = [100; 200; 300];  % GDP
city_data.K = [50; 100; 150];     % 资本存量

% 创建双边数据
bilateral_data = struct();
% 贸易流量矩阵
bilateral_data.trade_flow = [50, 20, 10; 
                             15, 100, 25; 
                             5, 30, 150];
% 距离矩阵
bilateral_data.distance = [0, 100, 200; 
                           100, 0, 150; 
                           200, 150, 0];

% 构建份额矩阵
trade = Trade();
shares = trade.constructShares(bilateral_data, city_data);

%% 测试1: 测试SteadyStateSolver的初始化
disp('测试1: 测试SteadyStateSolver的初始化');
try
    solver = SteadyStateSolver();
    disp('  通过: SteadyStateSolver成功初始化');
catch e
    disp(['  失败: ', e.message]);
end

%% 测试2: 测试求解稳态函数
disp('测试2: 测试求解稳态函数');
try
    [steady_state, converged] = solver.solve(params, city_data, shares);
    if converged
        disp('  通过: 稳态求解成功收敛');
    else
        disp('  警告: 稳态求解未收敛');
    end
    
    % 检查稳态结果结构
    expected_fields = {'w', 'r', 'v', 'a', 'K', 'p', 'GDP', 'c', 'labor_income', 'capital_income', 'welfare'};
    missing_fields = setdiff(expected_fields, fieldnames(steady_state));
    
    if isempty(missing_fields)
        disp('  通过: 稳态结果包含所有预期字段');
    else
        disp(['  失败: 稳态结果缺少字段: ', strjoin(missing_fields, ', ')]);
    end
    
    % 检查结果维度
    if length(steady_state.w) == params.C && length(steady_state.r) == params.C
        disp('  通过: 结果维度正确');
    else
        disp('  失败: 结果维度不正确');
    end
    
    % 检查结果非负性
    if all(steady_state.w > 0) && all(steady_state.r > 0) && all(steady_state.K > 0)
        disp('  通过: 结果满足非负性约束');
    else
        disp('  失败: 结果不满足非负性约束');
    end
    
catch e
    disp(['  失败: ', e.message]);
end

%% 测试3: 测试价格指数计算
disp('测试3: 测试价格指数计算');
try
    w = ones(params.C, 1);
    r = ones(params.C, 1);
    p = solver.computePriceIndex(w, r, params, city_data, shares);
    
    if length(p) == params.C
        disp('  通过: 价格指数维度正确');
    else
        disp('  失败: 价格指数维度不正确');
    end
    
    if all(p > 0)
        disp('  通过: 价格指数满足非负性约束');
    else
        disp('  失败: 价格指数不满足非负性约束');
    end
    
catch e
    disp(['  失败: ', e.message]);
end

%% 测试4: 测试不同参数下的稳态求解
disp('测试4: 测试不同参数下的稳态求解');

% 测试不同的贸易弹性
test_thetas = [3, 5, 7];
for i = 1:length(test_thetas)
    params.theta = test_thetas(i);
    try
        [~, converged] = solver.solve(params, city_data, shares);
        if converged
            disp(['  通过: 贸易弹性 = ', num2str(params.theta), ' 的稳态求解收敛']);
        else
            disp(['  警告: 贸易弹性 = ', num2str(params.theta), ' 的稳态求解未收敛']);
        end
    catch e
        disp(['  失败: 贸易弹性 = ', num2str(params.theta), ' 的稳态求解出错: ', e.message]);
    end
end

% 恢复原始参数
params.theta = 5;

%% 测试5: 测试边界情况
disp('测试5: 测试边界情况');

% 测试单城市情况
params_single = params;
params_single.C = 1;
city_data_single = struct();
city_data_single.pop = 1;
city_data_single.mu = 0.7;
city_data_single.GDP = 100;
city_data_single.K = 50;
bilateral_data_single = struct();
bilateral_data_single.trade_flow = 100;
bilateral_data_single.distance = 0;
shares_single = trade.constructShares(bilateral_data_single, city_data_single);

try
    [~, converged] = solver.solve(params_single, city_data_single, shares_single);
    if converged
        disp('  通过: 单城市情况的稳态求解收敛');
    else
        disp('  警告: 单城市情况的稳态求解未收敛');
    end
catch e
    disp(['  失败: 单城市情况的稳态求解出错: ', e.message]);
end

%% 测试总结
disp('单元测试完成'); 