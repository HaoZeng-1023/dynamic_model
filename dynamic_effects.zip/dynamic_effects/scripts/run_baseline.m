%% 城市间动态一般均衡模型 - 基准情景脚本
% 此脚本用于运行基准情景的模型分析

% 运行环境配置（如未运行）
if ~exist('project_root', 'var')
    % 获取当前脚本的绝对路径
    current_script_path = mfilename('fullpath');
    % 获取当前脚本所在的目录
    [script_dir, ~, ~] = fileparts(current_script_path);
    % 获取项目根目录（假设脚本位于scripts子目录）
    project_root = fileparts(script_dir);
    % 运行设置脚本
    run(fullfile(project_root, 'setup.m'));
end

%% 参数设置
% 定义输入文件路径
data_file = fullfile(project_root, 'data', 'config', 'default_params.json');
city_data_file = fullfile(project_root, 'data', 'raw', 'city_data.csv');
trade_data_file = fullfile(project_root, 'data', 'raw', 'trade_matrix.csv');
trade_cost_file = fullfile(project_root, 'data', 'raw', 'trade_cost_matrix.csv');
policy_file = fullfile(project_root, 'data', 'config', 'policy_scenarios', 'baseline.json');

% 创建数据加载器
dataLoader = DataLoader();

% 加载数据
[params, city_data, bilateral_data] = dataLoader.loadData(char(data_file), char(city_data_file), char(trade_data_file), char(trade_cost_file));
policy = dataLoader.loadPolicy(char(policy_file));

% 验证参数
paramValidator = ParameterValidator();
if ~paramValidator.validate(params, city_data, bilateral_data, policy)
    error('参数验证失败，请检查输入数据');
end

%% 构建初始份额矩阵
tradeModel = Trade();
shares = tradeModel.constructShares(bilateral_data, city_data);

%% 求解稳态
steadySolver = SteadyStateSolver();
[w0, r0, v0, a0] = steadySolver.solve(params, city_data, shares);

% 保存初始稳态结果
steady_state = struct();
steady_state.w = w0;
steady_state.r = r0;
steady_state.v = v0;
steady_state.a = a0;

%% 构建动态系统
dynamicSolver = DynamicSolver();
[Psi, Gamma, Theta, Pi] = dynamicSolver.constructDynamicMatrices(params, shares, city_data);
[P, R] = dynamicSolver.solveTransitionMatrix(Psi, Gamma, Theta, Pi);

%% 计算政策冲击
shock = dynamicSolver.computePolicyShock(policy, params, shares);

%% 求解转移路径
T_max = 200;  % 最大期数
trajectory = dynamicSolver.computeTransitionPath(P, R, shock, params, T_max);

%% 计算福利效应
welfareCalculator = WelfareCalculator();
welfare = welfareCalculator.computeWelfare(trajectory, params, steady_state);

%% 整理输出结果
results = struct();
results.steady_state = steady_state;
results.trajectory = trajectory;
results.welfare = welfare;
results.transition_matrix = P;

%% 保存结果
save_path = fullfile(project_root, 'results', 'baseline_results.mat');
save(char(save_path), 'results', 'params', 'city_data', 'bilateral_data', 'policy');

disp('基准情景分析完成！');
disp(['结果已保存到: ', char(save_path)]); 