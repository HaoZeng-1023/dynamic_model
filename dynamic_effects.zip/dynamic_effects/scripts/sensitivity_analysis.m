%% 敏感性分析脚本
% 此脚本用于分析模型对关键参数的敏感性

% 运行环境配置（如未运行）
if ~exist('project_root', 'var')
    run('../setup.m');
end

% 定义基本输入文件路径
data_file = fullfile(project_root, 'data', 'config', 'default_params.json');
city_data_file = fullfile(project_root, 'data', 'raw', 'city_data.csv');
trade_data_file = fullfile(project_root, 'data', 'raw', 'trade_matrix.csv');
distance_data_file = fullfile(project_root, 'data', 'raw', 'distance_matrix.csv');
policy_file = fullfile(project_root, 'data', 'config', 'policy_scenarios', 'trade_cost_reduction.json');

% 创建数据加载器
dataLoader = DataLoader();
validator = ParameterValidator();

% 加载基础数据
[params_base, city_data, bilateral_data] = dataLoader.loadData(data_file, city_data_file, trade_data_file, distance_data_file);
policy = dataLoader.loadPolicy(policy_file);

% 创建结果目录
results_dir = fullfile(project_root, 'results', 'sensitivity_analysis');
if ~exist(results_dir, 'dir')
    mkdir(results_dir);
end

% 定义要分析的参数及其取值范围
param_list = struct();
param_list.theta = [3, 4, 5, 6, 7];       % 贸易弹性
param_list.epsilon = [2, 3, 4, 5, 6];     % 资本替代弹性
param_list.beta = [0.93, 0.94, 0.95, 0.96, 0.97];  % 折现因子

% 存储敏感性分析结果
sensitivity_results = struct();

% 对每个参数进行敏感性分析
param_names = fieldnames(param_list);
for p = 1:length(param_names)
    param_name = param_names{p};
    param_values = param_list.(param_name);
    
    disp(['正在进行 ', param_name, ' 参数的敏感性分析...']);
    
    % 存储该参数的结果
    param_results = struct();
    param_results.param_values = param_values;
    param_results.welfare = cell(length(param_values), 1);
    
    for i = 1:length(param_values)
        % 复制基准参数
        params = params_base;
        
        % 修改当前参数值
        params.(param_name) = param_values(i);
        
        disp(['  - 参数值: ', num2str(param_values(i))]);
        
        % 验证参数
        validator.validate(params, city_data, bilateral_data, policy);
        
        % 构建初始份额矩阵
        trade = Trade();
        shares = trade.constructShares(bilateral_data, city_data);
        
        % 求解初始稳态
        disp('    正在求解初始稳态...');
        steadyStateSolver = SteadyStateSolver();
        [steady_state, converged] = steadyStateSolver.solve(params, city_data, shares);
        
        if ~converged
            warning('    初始稳态未收敛，结果可能不准确');
        end
        
        % 构建动态系统
        disp('    正在构建动态系统...');
        dynamicSolver = DynamicSolver();
        [Psi, Gamma, Theta, Pi] = dynamicSolver.constructDynamicMatrices(params, shares, city_data);
        [P, R] = dynamicSolver.solveTransitionMatrix(Psi, Gamma, Theta, Pi);
        
        % 计算政策冲击
        shock = dynamicSolver.computePolicyShock(policy, params, shares);
        
        % 求解转移路径
        disp('    正在计算转移路径...');
        T_max = 200;  % 最大期数
        trajectory = dynamicSolver.computeTransitionPath(P, R, shock, params, steady_state, T_max);
        
        % 计算福利效应
        disp('    正在计算福利效应...');
        welfareCalculator = WelfareCalculator();
        welfare = welfareCalculator.computeWelfare(trajectory, params, steady_state);
        
        % 存储结果
        param_results.welfare{i} = welfare;
        
        % 保存中间结果
        save(fullfile(results_dir, [param_name, '_', num2str(param_values(i)), '_results.mat']), ...
            'steady_state', 'trajectory', 'welfare', 'params');
    end
    
    % 将该参数的结果添加到总结果中
    sensitivity_results.(param_name) = param_results;
end

% 保存敏感性分析结果
save(fullfile(results_dir, 'sensitivity_results.mat'), 'sensitivity_results', 'param_list');

% 生成敏感性分析报告
disp('正在生成敏感性分析报告...');
% 这里可以添加生成报告的代码

% 完成
disp('敏感性分析完成！结果已保存到 results/sensitivity_analysis 目录。'); 