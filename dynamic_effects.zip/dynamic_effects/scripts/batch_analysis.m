%% 批量分析脚本
% 此脚本用于批量运行多个政策场景的分析

% 运行环境配置（如未运行）
if ~exist('project_root', 'var')
    run('../setup.m');
end

% 定义基本输入文件路径
data_file = fullfile(project_root, 'data', 'config', 'default_params.json');
city_data_file = fullfile(project_root, 'data', 'raw', 'city_data.csv');
trade_data_file = fullfile(project_root, 'data', 'raw', 'trade_matrix.csv');
distance_data_file = fullfile(project_root, 'data', 'raw', 'distance_matrix.csv');

% 获取所有政策场景文件
policy_dir = fullfile(project_root, 'data', 'config', 'policy_scenarios');
policy_files = dir(fullfile(policy_dir, '*.json'));

% 创建数据加载器和验证器
dataLoader = DataLoader();
validator = ParameterValidator();

% 加载基础数据（只需加载一次）
[params, city_data, bilateral_data] = dataLoader.loadData(data_file, city_data_file, trade_data_file, distance_data_file);

% 构建初始份额矩阵
trade = Trade();
shares = trade.constructShares(bilateral_data, city_data);

% 求解初始稳态（只需求解一次）
disp('正在求解初始稳态...');
steadyStateSolver = SteadyStateSolver();
[steady_state, converged] = steadyStateSolver.solve(params, city_data, shares);

if ~converged
    warning('初始稳态未收敛，结果可能不准确');
else
    disp('初始稳态求解成功');
end

% 构建动态系统（只需构建一次）
disp('正在构建动态系统...');
dynamicSolver = DynamicSolver();
[Psi, Gamma, Theta, Pi] = dynamicSolver.constructDynamicMatrices(params, shares, city_data);
[P, R] = dynamicSolver.solveTransitionMatrix(Psi, Gamma, Theta, Pi);

% 创建结果目录
results_dir = fullfile(project_root, 'results', 'batch_analysis');
if ~exist(results_dir, 'dir')
    mkdir(results_dir);
end

% 批量运行所有政策场景
for i = 1:length(policy_files)
    policy_file = fullfile(policy_dir, policy_files(i).name);
    [~, scenario_name, ~] = fileparts(policy_files(i).name);
    
    disp(['正在分析政策场景: ', scenario_name]);
    
    % 加载政策
    policy = dataLoader.loadPolicy(policy_file);
    
    % 验证参数
    validator.validate(params, city_data, bilateral_data, policy);
    
    % 计算政策冲击
    shock = dynamicSolver.computePolicyShock(policy, params, shares);
    
    % 求解转移路径
    disp('正在计算转移路径...');
    T_max = 200;  % 最大期数
    trajectory = dynamicSolver.computeTransitionPath(P, R, shock, params, steady_state, T_max);
    
    % 计算福利效应
    disp('正在计算福利效应...');
    welfareCalculator = WelfareCalculator();
    welfare = welfareCalculator.computeWelfare(trajectory, params, steady_state);
    
    % 保存结果
    save(fullfile(results_dir, [scenario_name, '_results.mat']), ...
        'steady_state', 'trajectory', 'welfare', 'policy');
    
    % 生成报告
    reportGenerator = ReportGenerator();
    reportGenerator.generateReport(steady_state, trajectory, welfare, city_data, params, policy);
    
    disp(['政策场景 ', scenario_name, ' 分析完成！']);
end

% 汇总分析
disp('正在生成汇总分析...');
% 这里可以添加汇总分析的代码

% 完成
disp('批量分析完成！所有结果已保存到 results/batch_analysis 目录。'); 