%% 运行反事实分析
% 此脚本用于运行政策变化的反事实分析

% 运行环境配置（如未运行）
if ~exist('project_root', 'var')
    run('../setup.m');
end

% 定义输入文件路径
data_file = fullfile(project_root, 'data', 'config', 'default_params.json');
city_data_file = fullfile(project_root, 'data', 'raw', 'city_data.csv');
trade_data_file = fullfile(project_root, 'data', 'raw', 'trade_matrix.csv');
distance_data_file = fullfile(project_root, 'data', 'raw', 'distance_matrix.csv');
policy_file = fullfile(project_root, 'data', 'config', 'policy_scenarios', 'trade_cost_reduction.json');

% 创建数据加载器
dataLoader = DataLoader();

% 加载数据
[params, city_data, bilateral_data] = dataLoader.loadData(data_file, city_data_file, trade_data_file, distance_data_file);
policy = dataLoader.loadPolicy(policy_file);

% 验证参数
validator = ParameterValidator();
validator.validate(params, city_data, bilateral_data, policy);

% 构建初始份额矩阵
trade = Trade();
shares = trade.constructShares(bilateral_data, city_data);

% 求解初始稳态
disp('正在求解初始稳态...');
steadyStateSolver = SteadyStateSolver();
[steady_state, converged] = steadyStateSolver.solve(params, city_data, shares);

if ~converged
    warning('初始稳态未收敛，结果可能不准确');
else
    disp('初始稳态求解成功');
end

% 构建动态系统
disp('正在构建动态系统...');
dynamicSolver = DynamicSolver();
[Psi, Gamma, Theta, Pi] = dynamicSolver.constructDynamicMatrices(params, shares, city_data);
[P, R] = dynamicSolver.solveTransitionMatrix(Psi, Gamma, Theta, Pi);

% 计算政策冲击
shock = dynamicSolver.computePolicyShock(policy, params, shares);

% 求解转移路径
disp('正在计算转移路径...');
T_max = 200;  % 最大期数
trajectory = dynamicSolver.computeTransitionPath(P, R, shock, params, steady_state, T_max);

% 计算福利效应
disp('正在计算福利效应...');
welfareCalculator = WelfareCalculator();
welfare = welfareCalculator.computeWelfare(trajectory, params, steady_state);

% 保存结果
save(fullfile(project_root, 'results', 'counterfactual', 'trade_cost_reduction_results.mat'), ...
    'steady_state', 'trajectory', 'welfare', 'policy');

% 生成可视化
plotTrajectory = PlotTrajectory();
plotTrajectory.plot(trajectory, city_data);

mapVisualizer = MapVisualizer();
mapVisualizer.plotWelfare(welfare, city_data);

% 生成报告
reportGenerator = ReportGenerator();
reportGenerator.generateReport(steady_state, trajectory, welfare, city_data, params, policy);

% 完成
disp('反事实分析完成！结果已保存到 results/counterfactual 目录。'); 