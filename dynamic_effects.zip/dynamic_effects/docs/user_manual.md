# 城市间动态一般均衡模型 - 用户手册

## 1. 简介

城市间动态一般均衡模型（CDGE Model）是一个用于评估政策变化（如基础设施投资导致的贸易成本下降）对各城市经济的动态影响的MATLAB工具。本手册将指导您如何安装、配置和使用该模型。

## 2. 安装与配置

### 2.1 系统要求
- MATLAB R2019b 或更高版本
- Optimization Toolbox
- Statistics and Machine Learning Toolbox

### 2.2 安装步骤
1. 下载项目代码库
2. 解压到您的工作目录
3. 在MATLAB中运行 `setup.m` 脚本以配置环境

```matlab
>> cd /path/to/CDGE_Model
>> setup
```

## 3. 数据准备

### 3.1 必需的输入数据
模型需要以下输入数据：

1. **城市基础数据** (`data/raw/city_data.csv`)：
   - 城市名称
   - GDP
   - 人口
   - 劳动收入占比

2. **双边贸易数据** (`data/raw/trade_matrix.csv`)：
   - 城市间贸易流量（C×C矩阵）

3. **地理数据** (`data/raw/distance_matrix.csv`)：
   - 城市间距离（用于估算贸易和投资成本）

### 3.2 数据格式
- CSV文件格式
- 第一行应为列标题
- 城市名称应在所有文件中保持一致

### 3.3 参数配置
模型参数在 `data/config/default_params.json` 文件中设置：

```json
{
    "model_params": {
        "C": 30,           // 城市数量
        "beta": 0.95,      // 折现因子
        "psi": 0.5,        // 跨期替代弹性
        "delta": 0.05,     // 折旧率
        "theta": 5,        // 贸易弹性
        "epsilon": 4       // 资本替代弹性
    },
    // 其他参数...
}
```

## 4. 运行模型

### 4.1 基本运行
要运行基准情景分析，在MATLAB中执行：

```matlab
>> run_main
```

### 4.2 使用脚本
项目提供了多个脚本以便于分析：

- `scripts/run_baseline.m` - 运行基准情景
- `scripts/run_counterfactual.m` - 运行反事实分析
- `scripts/batch_analysis.m` - 批量运行多个政策场景
- `scripts/sensitivity_analysis.m` - 进行参数敏感性分析

### 4.3 政策场景配置
政策场景在 `data/config/policy_scenarios/` 目录下配置：

```json
{
    "scenario_name": "贸易成本下降",
    "description": "模拟基础设施投资导致的贸易成本下降",
    "tax": [0],
    "tau_change": 0.9,        // 贸易成本变化倍数（0.9表示下降10%）
    "T_announce": 5,          // 政策宣布时期
    "T_implement": 10         // 政策实施时期
}
```

## 5. 结果分析

### 5.1 输出结果
模型将输出以下结果：

- **稳态结果**：各城市的工资、资本存量、财富水平
- **动态路径**：政策实施后的经济变量演化
- **福利分析**：各城市的福利变化（消费等价变化）

### 5.2 可视化
模型自动生成以下可视化图表：

- 财富和消费的动态路径
- 城市间资本流动
- 福利变化地图

### 5.3 结果文件
所有结果文件保存在 `results/` 目录下：

- `results/steady_state/` - 稳态结果
- `results/dynamics/` - 动态结果
- `results/welfare/` - 福利分析
- `results/reports/` - 生成的报告

## 6. 高级功能

### 6.1 自定义政策场景
您可以通过创建新的政策配置文件来定义自己的政策场景：

1. 在 `data/config/policy_scenarios/` 目录下创建新的JSON文件
2. 定义政策参数
3. 使用 `run_counterfactual.m` 或 `batch_analysis.m` 运行分析

### 6.2 参数敏感性分析
使用 `scripts/sensitivity_analysis.m` 脚本分析模型对关键参数的敏感性。

### 6.3 扩展模型
如需扩展模型功能，可以修改以下模块：

- `src/core/` - 核心计算模块
- `src/models/` - 模型组件
- `src/utils/` - 工具函数
- `src/visualization/` - 可视化模块

## 7. 常见问题

### 7.1 收敛问题
如果模型无法收敛，请尝试：

- 增加最大迭代次数
- 调整阻尼系数
- 检查初始值设置

### 7.2 内存问题
对于大规模问题（城市数量>100），可能会遇到内存限制。建议：

- 使用稀疏矩阵表示
- 减少保存的中间结果
- 增加计算机内存

### 7.3 技术支持
如有技术问题，请联系项目维护者或参考技术文档。 