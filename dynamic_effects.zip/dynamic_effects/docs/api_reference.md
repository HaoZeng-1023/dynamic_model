# 城市间动态一般均衡模型 - API参考

本文档提供了城市间动态一般均衡模型（CDGE Model）的API参考，详细说明了各个类和方法的用法。

## 目录

1. [核心模块](#1-核心模块)
2. [模型组件](#2-模型组件)
3. [工具函数](#3-工具函数)
4. [可视化模块](#4-可视化模块)

## 1. 核心模块

### 1.1 SteadyStateSolver

稳态求解器类，用于求解经济系统的稳态均衡。

#### 属性
- `max_iter` - 最大迭代次数，默认为1000
- `tol` - 收敛容差，默认为1e-8
- `damping` - 阻尼系数，默认为0.5

#### 方法
```matlab
[steady_state, converged] = solve(obj, params, city_data, shares)
```
求解经济系统的稳态。

**输入参数**:
- `params` - 模型参数结构体
- `city_data` - 城市特征数据结构体
- `shares` - 份额矩阵结构体

**输出参数**:
- `steady_state` - 稳态结果结构体
- `converged` - 是否收敛的标志

```matlab
p = computePriceIndex(obj, w, r, params, city_data, shares)
```
计算价格指数。

**输入参数**:
- `w` - 各城市工资向量
- `r` - 各城市资本租金率向量
- `params` - 模型参数结构体
- `city_data` - 城市特征数据结构体
- `shares` - 份额矩阵结构体

**输出参数**:
- `p` - 各城市价格指数向量

### 1.2 DynamicSolver

动态求解器类，用于构建和求解动态系统。

#### 属性
- `tol` - 求解特征值问题的容差，默认为1e-10

#### 方法
```matlab
[Psi, Gamma, Theta, Pi] = constructDynamicMatrices(obj, params, shares, city_data)
```
构建动态系统的线性化系数矩阵。

**输入参数**:
- `params` - 模型参数结构体
- `shares` - 份额矩阵结构体
- `city_data` - 城市特征数据结构体

**输出参数**:
- `Psi` - 财富t+2项系数矩阵
- `Gamma` - 财富t+1项系数矩阵
- `Theta` - 财富t项系数矩阵
- `Pi` - 外生冲击系数矩阵

```matlab
[P, R] = solveTransitionMatrix(obj, Psi, Gamma, Theta, Pi)
```
求解转移矩阵。

**输入参数**:
- `Psi`, `Gamma`, `Theta`, `Pi` - 动态系统系数矩阵

**输出参数**:
- `P` - 财富动态转移矩阵
- `R` - 冲击影响矩阵

```matlab
shock = computePolicyShock(obj, policy, params, shares)
```
计算政策冲击。

**输入参数**:
- `policy` - 政策参数结构体
- `params` - 模型参数结构体
- `shares` - 份额矩阵结构体

**输出参数**:
- `shock` - 冲击结构体

```matlab
trajectory = computeTransitionPath(obj, P, R, shock, params, steady_state, T_max)
```
计算转移路径。

**输入参数**:
- `P` - 财富动态转移矩阵
- `R` - 冲击影响矩阵
- `shock` - 冲击结构体
- `params` - 模型参数结构体
- `steady_state` - 稳态结果结构体
- `T_max` - 最大期数

**输出参数**:
- `trajectory` - 转移路径结构体

### 1.3 EquilibriumSystem

均衡系统类，处理市场出清和均衡条件。

#### 方法
```matlab
[labor_income, capital_income] = computeMarketClearing(obj, w, r, v, a, params, city_data, shares)
```
计算市场出清条件。

**输入参数**:
- `w` - 各城市工资向量
- `r` - 各城市资本租金率向量
- `v` - 各城市资本收入率向量
- `a` - 各城市财富向量
- `params` - 模型参数结构体
- `city_data` - 城市特征数据结构体
- `shares` - 份额矩阵结构体

**输出参数**:
- `labor_income` - 劳动收入向量
- `capital_income` - 资本收入向量

```matlab
[error, w_new, r_new] = checkEquilibrium(obj, w, r, v, a, params, city_data, shares)
```
检查均衡条件。

**输入参数**:
- `w`, `r`, `v`, `a` - 经济变量
- `params`, `city_data`, `shares` - 模型参数和数据

**输出参数**:
- `error` - 均衡误差
- `w_new`, `r_new` - 更新后的工资和资本租金率

### 1.4 WelfareCalculator

福利计算器类，用于评估政策变化的福利效应。

#### 方法
```matlab
welfare = computeWelfare(obj, trajectory, params, steady_state)
```
计算福利效应。

**输入参数**:
- `trajectory` - 转移路径结构体
- `params` - 模型参数结构体
- `steady_state` - 稳态结果结构体

**输出参数**:
- `welfare` - 福利结果结构体

```matlab
lambda = consumptionEquivalent(obj, welfare_change, params)
```
计算消费等价变化。

**输入参数**:
- `welfare_change` - 福利变化
- `params` - 模型参数结构体

**输出参数**:
- `lambda` - 消费等价变化

## 2. 模型组件

### 2.1 Trade

贸易模块类，处理贸易份额和贸易成本。

#### 方法
```matlab
shares = constructShares(obj, bilateral_data, city_data)
```
从观测数据构建初始份额矩阵。

**输入参数**:
- `bilateral_data` - 双边矩阵数据结构体
- `city_data` - 城市特征数据结构体

**输出参数**:
- `shares` - 份额矩阵结构体

```matlab
tau = estimateTradeBarriers(obj, shares, city_data, params, bilateral_data)
```
估算贸易障碍。

**输入参数**:
- `shares` - 份额矩阵结构体
- `city_data` - 城市特征数据结构体
- `params` - 模型参数结构体
- `bilateral_data` - 双边矩阵数据结构体

**输出参数**:
- `tau` - 贸易成本矩阵

```matlab
S_new = updateTradeShares(obj, w, r, params, city_data, shares)
```
更新贸易份额。

**输入参数**:
- `w` - 工资向量
- `r` - 资本租金率向量
- `params` - 模型参数结构体
- `city_data` - 城市特征数据结构体
- `shares` - 份额矩阵结构体

**输出参数**:
- `S_new` - 更新后的贸易份额矩阵

### 2.2 Capital

资本市场类，处理资本流动和投资决策。

#### 方法
```matlab
[B_new, v_new] = updateCapitalShares(obj, r, params, shares)
```
更新资本份额。

**输入参数**:
- `r` - 资本租金率向量
- `params` - 模型参数结构体
- `shares` - 份额矩阵结构体

**输出参数**:
- `B_new` - 更新后的资本份额矩阵
- `v_new` - 更新后的资本收入率向量

```matlab
capital_income = computeCapitalIncome(obj, a, v, shares)
```
计算资本收入。

**输入参数**:
- `a` - 财富向量
- `v` - 资本收入率向量
- `shares` - 份额矩阵结构体

**输出参数**:
- `capital_income` - 资本收入向量

### 2.3 Household

家庭部门类，处理消费和劳动供给。

#### 方法
```matlab
c = computeConsumption(obj, GDP, K, params)
```
计算消费。

**输入参数**:
- `GDP` - GDP向量
- `K` - 资本存量向量
- `params` - 模型参数结构体

**输出参数**:
- `c` - 消费向量

```matlab
utility = computeUtility(obj, c, params)
```
计算效用。

**输入参数**:
- `c` - 消费向量
- `params` - 模型参数结构体

**输出参数**:
- `utility` - 效用向量

### 2.4 Production

生产部门类，处理生产和要素需求。

#### 方法
```matlab
GDP = computeOutput(obj, L, K, params, city_data)
```
计算产出。

**输入参数**:
- `L` - 劳动投入向量
- `K` - 资本投入向量
- `params` - 模型参数结构体
- `city_data` - 城市特征数据结构体

**输出参数**:
- `GDP` - 产出向量

```matlab
[w, r] = computeFactorPrices(obj, L, K, params, city_data)
```
计算要素价格。

**输入参数**:
- `L` - 劳动投入向量
- `K` - 资本投入向量
- `params` - 模型参数结构体
- `city_data` - 城市特征数据结构体

**输出参数**:
- `w` - 工资向量
- `r` - 资本租金率向量

## 3. 工具函数

### 3.1 DataLoader

数据加载器类，读取和处理输入数据。

#### 方法
```matlab
[params, city_data, bilateral_data] = loadData(obj, data_file, city_data_file, trade_data_file, distance_data_file)
```
加载数据。

**输入参数**:
- `data_file` - 参数配置文件路径
- `city_data_file` - 城市数据文件路径
- `trade_data_file` - 贸易矩阵文件路径
- `distance_data_file` - 距离矩阵文件路径

**输出参数**:
- `params` - 模型参数结构体
- `city_data` - 城市特征数据结构体
- `bilateral_data` - 双边矩阵数据结构体

```matlab
policy = loadPolicy(obj, policy_file)
```
加载政策配置。

**输入参数**:
- `policy_file` - 政策配置文件路径

**输出参数**:
- `policy` - 政策参数结构体

### 3.2 ParameterValidator

参数验证器类，验证模型参数的有效性。

#### 方法
```matlab
isValid = validate(obj, params, city_data, bilateral_data, policy)
```
验证参数。

**输入参数**:
- `params` - 模型参数结构体
- `city_data` - 城市特征数据结构体
- `bilateral_data` - 双边矩阵数据结构体
- `policy` - 政策参数结构体

**输出参数**:
- `isValid` - 参数是否有效的标志

### 3.3 MatrixOperations

矩阵运算工具类，提供矩阵运算的辅助函数。

#### 方法
```matlab
X_sparse = toSparse(obj, X, threshold)
```
将矩阵转换为稀疏矩阵。

**输入参数**:
- `X` - 原始矩阵
- `threshold` - 稀疏化阈值

**输出参数**:
- `X_sparse` - 稀疏矩阵

```matlab
X_normalized = normalize(obj, X, dim)
```
归一化矩阵。

**输入参数**:
- `X` - 原始矩阵
- `dim` - 归一化维度

**输出参数**:
- `X_normalized` - 归一化后的矩阵

### 3.4 Convergence

收敛判断工具类，检测迭代算法的收敛性。

#### 方法
```matlab
[converged, error] = check(obj, x_new, x_old, tol)
```
检查收敛性。

**输入参数**:
- `x_new` - 新值
- `x_old` - 旧值
- `tol` - 收敛容差

**输出参数**:
- `converged` - 是否收敛的标志
- `error` - 误差

## 4. 可视化模块

### 4.1 PlotTrajectory

轨迹绘图类，绘制动态转移路径。

#### 方法
```matlab
plot(obj, trajectory, city_data)
```
绘制转移路径。

**输入参数**:
- `trajectory` - 转移路径结构体
- `city_data` - 城市特征数据结构体

```matlab
plotVariable(obj, variable, variable_name, city_data)
```
绘制特定变量的路径。

**输入参数**:
- `variable` - 变量矩阵（C×T）
- `variable_name` - 变量名称
- `city_data` - 城市特征数据结构体

### 4.2 MapVisualizer

地图可视化类，在地图上展示福利变化。

#### 方法
```matlab
plotWelfare(obj, welfare, city_data)
```
绘制福利变化地图。

**输入参数**:
- `welfare` - 福利结果结构体
- `city_data` - 城市特征数据结构体

```matlab
plotVariable(obj, variable, variable_name, city_data)
```
在地图上绘制特定变量。

**输入参数**:
- `variable` - 变量向量（C×1）
- `variable_name` - 变量名称
- `city_data` - 城市特征数据结构体

### 4.3 ReportGenerator

报告生成器类，自动生成分析报告。

#### 方法
```matlab
generateReport(obj, steady_state, trajectory, welfare, city_data, params, policy)
```
生成报告。

**输入参数**:
- `steady_state` - 稳态结果结构体
- `trajectory` - 转移路径结构体
- `welfare` - 福利结果结构体
- `city_data` - 城市特征数据结构体
- `params` - 模型参数结构体
- `policy` - 政策参数结构体

```matlab
generateTable(obj, data, headers, title)
```
生成表格。

**输入参数**:
- `data` - 表格数据
- `headers` - 表头
- `title` - 表格标题

**输出参数**:
- 表格对象 