%% 城市间动态一般均衡模型 - 基本用法示例
% 本示例展示了模型的基本使用方法

%% 1. 环境配置
% 运行环境配置脚本
run('../../setup.m');

%% 2. 加载数据
% 定义输入文件路径
data_file = fullfile(project_root, 'data', 'config', 'default_params.json');
city_data_file = fullfile(project_root, 'data', 'raw', 'city_data.csv');
trade_data_file = fullfile(project_root, 'data', 'raw', 'trade_matrix.csv');
distance_data_file = fullfile(project_root, 'data', 'raw', 'distance_matrix.csv');
policy_file = fullfile(project_root, 'data', 'config', 'policy_scenarios', 'baseline.json');

% 创建数据加载器
dataLoader = DataLoader();

% 加载数据
[params, city_data, bilateral_data] = dataLoader.loadData(data_file, city_data_file, trade_data_file, distance_data_file);
policy = dataLoader.loadPolicy(policy_file);

% 验证参数
validator = ParameterValidator();
validator.validate(params, city_data, bilateral_data, policy);

%% 3. 构建初始份额矩阵
trade = Trade();
shares = trade.constructShares(bilateral_data, city_data);

%% 4. 求解初始稳态
disp('正在求解初始稳态...');
steadyStateSolver = SteadyStateSolver();
[steady_state, converged] = steadyStateSolver.solve(params, city_data, shares);

if ~converged
    warning('初始稳态未收敛，结果可能不准确');
else
    disp('初始稳态求解成功');
    
    % 显示稳态结果摘要
    disp('稳态结果摘要:');
    disp(['  平均工资: ', num2str(mean(steady_state.w))]);
    disp(['  平均资本租金率: ', num2str(mean(steady_state.r))]);
    disp(['  总GDP: ', num2str(sum(steady_state.GDP))]);
    disp(['  总资本存量: ', num2str(sum(steady_state.K))]);
end

%% 5. 构建动态系统
disp('正在构建动态系统...');
dynamicSolver = DynamicSolver();
[Psi, Gamma, Theta, Pi] = dynamicSolver.constructDynamicMatrices(params, shares, city_data);
[P, R] = dynamicSolver.solveTransitionMatrix(Psi, Gamma, Theta, Pi);

%% 6. 定义政策冲击
% 创建一个贸易成本下降10%的政策冲击
policy_shock = policy;
policy_shock.tau_change = 0.9 * ones(params.C, params.C);  % 所有城市对之间贸易成本下降10%
policy_shock.T_announce = 5;   % 第5期宣布政策
policy_shock.T_implement = 10; % 第10期实施政策

% 计算政策冲击
shock = dynamicSolver.computePolicyShock(policy_shock, params, shares);

%% 7. 求解转移路径
disp('正在计算转移路径...');
T_max = 100;  % 最大期数
trajectory = dynamicSolver.computeTransitionPath(P, R, shock, params, steady_state, T_max);

%% 8. 计算福利效应
disp('正在计算福利效应...');
welfareCalculator = WelfareCalculator();
welfare = welfareCalculator.computeWelfare(trajectory, params, steady_state);

% 显示福利效应摘要
disp('福利效应摘要:');
disp(['  平均消费等价变化: ', num2str(mean(welfare.consumption_equivalent) * 100), '%']);
disp(['  最大消费等价变化: ', num2str(max(welfare.consumption_equivalent) * 100), '%']);
disp(['  最小消费等价变化: ', num2str(min(welfare.consumption_equivalent) * 100), '%']);

%% 9. 可视化结果
% 绘制转移路径
plotTrajectory = PlotTrajectory();
plotTrajectory.plot(trajectory, city_data);

% 绘制福利变化地图
mapVisualizer = MapVisualizer();
mapVisualizer.plotWelfare(welfare, city_data);

%% 10. 保存结果
save(fullfile(project_root, 'results', 'examples', 'basic_usage_results.mat'), ...
    'steady_state', 'trajectory', 'welfare', 'policy_shock');

disp('示例运行完成！结果已保存到 results/examples 目录。'); 