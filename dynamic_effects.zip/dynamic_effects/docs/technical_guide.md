# 城市间动态一般均衡模型 - 技术指南

## 1. 模型概述

城市间动态一般均衡模型（CDGE Model）是一个多城市空间动态一般均衡模型，用于分析政策变化对城市经济的动态影响。本文档详细介绍模型的理论基础、实现方法和技术细节。

## 2. 理论框架

### 2.1 基本设定
模型考虑了C个城市和1个外部区域（ROW），每个城市有以下特征：
- 人口 ℓ_i（外生给定）
- 劳动份额 μ_i
- 初始资本存量 K_i
- 初始GDP

### 2.2 家庭部门
家庭部门提供劳动力并做出消费和储蓄决策。家庭效用函数为：

$$U_i = \sum_{t=0}^{\infty} \beta^t \frac{c_{i,t}^{1-1/\psi}}{1-1/\psi}$$

其中：
- $\beta$ 是折现因子
- $\psi$ 是跨期替代弹性
- $c_{i,t}$ 是t期的消费

### 2.3 生产部门
生产部门使用劳动和资本生产商品。生产函数为：

$$Y_i = z_i L_i^{\mu_i} K_i^{1-\mu_i}$$

其中：
- $z_i$ 是生产率
- $L_i$ 是劳动投入
- $K_i$ 是资本投入
- $\mu_i$ 是劳动份额

### 2.4 贸易
城市间贸易遵循Armington假设，贸易成本为iceberg形式。贸易份额为：

$$S_{ni} = \frac{(p_i \tau_{ni})^{-\theta}}{\sum_h (p_h \tau_{nh})^{-\theta}}$$

其中：
- $p_i$ 是城市i的价格
- $\tau_{ni}$ 是从i到n的贸易成本
- $\theta$ 是贸易弹性

### 2.5 资本市场
资本市场允许跨城市投资，资本份额为：

$$B_{ni} = \frac{(r_i / \kappa_{ni})^{\epsilon}}{\sum_h (r_h / \kappa_{nh})^{\epsilon}}$$

其中：
- $r_i$ 是城市i的资本租金率
- $\kappa_{ni}$ 是从n到i的投资成本
- $\epsilon$ 是资本替代弹性

## 3. 数学推导

### 3.1 稳态均衡条件

稳态时，所有变量不随时间变化。核心均衡条件包括：

**商品市场出清**：
$$w_i \ell_i / \mu_i = \sum_n S_{ni} (v_n a_n + w_n \ell_n)$$

**资本市场出清**：
$$(1-\mu_i) w_i \ell_i / \mu_i = \sum_n v_n B_{ni} a_n$$

**贸易份额**：
$$S_{ni} = \frac{(\tau_{ni} w_i^{\mu_i} r_i^{1-\mu_i} / z_i)^{-\theta}}{\sum_h (\tau_{nh} w_h^{\mu_h} r_h^{1-\mu_h} / z_h)^{-\theta}}$$

**资本份额**：
$$B_{ni} = \frac{(r_i / \kappa_{ni})^{\epsilon}}{\sum_h (r_h / \kappa_{nh})^{\epsilon}}$$

**资本收入率**：
$$v_n = \gamma \left[ \sum_h (r_h / \kappa_{nh})^{\epsilon} \right]^{1/\epsilon}$$

### 3.2 动态系统线性化

围绕稳态线性化后，财富的动态方程为：

$$\Psi \tilde{a}_{t+2} = \Gamma \tilde{a}_{t+1} + \Theta \tilde{a}_t + \Pi \tilde{f}$$

其中：
- $\tilde{a}_t = \ln(a_t) - \ln(a^*)$ 是财富的对数偏离
- $\tilde{f}$ 是外生冲击向量
- $\Psi$, $\Gamma$, $\Theta$, $\Pi$ 是系数矩阵

## 4. 数值方法

### 4.1 稳态求解算法

稳态求解采用迭代算法：

1. 初始化工资 $w$ 和资本租金率 $r$
2. 更新贸易份额 $S$ 和资本份额 $B$
3. 计算价格指数 $p$ 和资本收入率 $v$
4. 从市场出清条件更新 $w$ 和 $r$
5. 检查收敛性，如未收敛返回步骤2

### 4.2 动态系统求解

动态系统求解步骤：

1. 构建系数矩阵 $\Psi$, $\Gamma$, $\Theta$, $\Pi$
2. 将二阶差分方程转化为一阶系统
3. 求解广义特征值问题，得到转移矩阵 $P$
4. 计算冲击影响矩阵 $R$
5. 求解转移路径

## 5. 代码实现

### 5.1 核心模块

#### 5.1.1 SteadyStateSolver
实现稳态求解算法，主要方法：
- `solve(params, city_data, shares)` - 求解稳态
- `computePriceIndex(w, r, params, city_data, shares)` - 计算价格指数

#### 5.1.2 DynamicSolver
实现动态系统求解，主要方法：
- `constructDynamicMatrices(params, shares, city_data)` - 构建动态系数矩阵
- `solveTransitionMatrix(Psi, Gamma, Theta, Pi)` - 求解转移矩阵
- `computePolicyShock(policy, params, shares)` - 计算政策冲击
- `computeTransitionPath(P, R, shock, params, steady_state, T_max)` - 计算转移路径

### 5.2 模型组件

#### 5.2.1 Trade
实现贸易模块，主要方法：
- `constructShares(bilateral_data, city_data)` - 构建份额矩阵
- `estimateTradeBarriers(shares, city_data, params, bilateral_data)` - 估算贸易障碍
- `updateTradeShares(w, r, params, city_data, shares)` - 更新贸易份额

#### 5.2.2 Capital
实现资本市场，主要方法：
- `updateCapitalShares(r, params, shares)` - 更新资本份额
- `computeCapitalIncome(a, v, shares)` - 计算资本收入

## 6. 数值优化

### 6.1 计算效率优化
- 使用矩阵运算代替循环
- 对大规模问题使用稀疏矩阵
- 并行计算不同政策方案

### 6.2 数值稳定性
- 使用阻尼更新避免振荡
- 处理特殊情况（如零值）
- 归一化以保持数值稳定

### 6.3 内存管理
- 避免不必要的中间变量
- 适时清理大型数组
- 使用结构体组织数据

## 7. 扩展与定制

### 7.1 添加新的政策冲击
要添加新的政策冲击类型：
1. 在 `policy` 结构体中添加新字段
2. 修改 `DynamicSolver.computePolicyShock()` 方法
3. 更新相关的影响矩阵

### 7.2 修改模型假设
要修改基本模型假设：
1. 更新相应的均衡条件
2. 修改 `SteadyStateSolver` 和 `DynamicSolver` 类
3. 调整线性化方程

### 7.3 添加新的分析工具
要添加新的分析工具：
1. 在 `src/visualization/` 目录下创建新类
2. 实现所需的分析和可视化方法
3. 在主程序中调用新工具

## 8. 参考文献

1. Allen, T., & Arkolakis, C. (2014). Trade and the Topography of the Spatial Economy. *Quarterly Journal of Economics*.
2. Caliendo, L., Parro, F., Rossi-Hansberg, E., & Sarte, P. D. (2018). The Impact of Regional and Sectoral Productivity Changes on the U.S. Economy. *Review of Economic Studies*.
3. Redding, S. J. (2016). Goods Trade, Factor Mobility and Welfare. *Journal of International Economics*.
4. Monte, F., Redding, S. J., & Rossi-Hansberg, E. (2018). Commuting, Migration, and Local Employment Elasticities. *American Economic Review*. 