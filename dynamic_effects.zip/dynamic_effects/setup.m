%% 城市间动态一般均衡模型 - 环境配置脚本
% 此脚本用于设置MATLAB环境，添加所需的路径

% 清除工作空间和关闭所有图形窗口
clear all;
close all;

% 获取当前目录（项目根目录）
project_root = pwd;

% 添加各个子目录到路径
addpath(genpath(char(fullfile(project_root, 'src'))));
addpath(char(fullfile(project_root, 'data')));
addpath(char(fullfile(project_root, 'scripts')));

% 创建结果目录（如果不存在）
dirs_to_create = {
    fullfile(project_root, 'results'), ...
    fullfile(project_root, 'results', 'steady_state'), ...
    fullfile(project_root, 'results', 'dynamics'), ...
    fullfile(project_root, 'results', 'welfare'), ...
    fullfile(project_root, 'results', 'reports')
};

for i = 1:length(dirs_to_create)
    if ~exist(char(dirs_to_create{i}), 'dir')
        mkdir(char(dirs_to_create{i}));
    end
end

% 显示设置完成信息
disp('环境设置完成！项目路径已添加到MATLAB路径。');
disp(['项目根目录: ', project_root]);

% 检查必要的工具箱
required_toolboxes = {'optimization', 'statistics'};
missing_toolboxes = {};

for i = 1:length(required_toolboxes)
    if ~license('test', [required_toolboxes{i}, '_toolbox'])
        missing_toolboxes{end+1} = required_toolboxes{i};
    end
end

if ~isempty(missing_toolboxes)
    warning('缺少推荐的工具箱: %s', strjoin(missing_toolboxes, ', '));
    disp('项目可能无法完全发挥功能。');
else
    disp('所有推荐的工具箱都已安装。');
end

% 输出版本信息
disp(['MATLAB 版本: ', version]);

%% 数据输入要求说明
disp(' ');
disp('======================================================================');
disp('                       数据输入要求说明                                ');
disp('======================================================================');
disp('本模型需要以下数据文件，请确保它们存在于正确的位置并符合格式要求：');
disp(' ');

% 城市数据文件说明
disp('1. 城市基础数据文件');
disp('   路径: data/raw/city_data.csv');
disp('   格式: CSV文件，第一行为列标题');
disp('   必需列:');
disp('     - city_name: 城市名称（字符串）');
disp('     - pop: 城市人口（万人）');
disp('     - mu: 劳动份额（0-1之间的小数）');
disp('     - GDP: 城市GDP（亿元）');
disp('     - K: 资本存量（亿元）');
disp('   注意: 所有城市必须按相同顺序出现在所有数据文件中');
disp(' ');

% 贸易矩阵文件说明
disp('2. 贸易流量矩阵文件');
disp('   路径: data/raw/trade_matrix.csv');
disp('   格式: CSV文件，无标题行');
disp('   内容: C×C矩阵，其中C为城市数量');
disp('   含义: 矩阵元素E_ij表示从城市j到城市i的贸易流量');
disp('   单位: 亿元');
disp('   注意: 行列顺序必须与城市数据文件中的城市顺序一致');
disp(' ');

% 贸易成本矩阵文件说明
disp('3. 贸易成本矩阵文件');
disp('   路径: data/raw/trade_cost_matrix.csv');
disp('   格式: CSV文件，无标题行');
disp('   内容: C×C矩阵，其中C为城市数量');
disp('   含义: 矩阵元素tau_ij表示从城市j到城市i的贸易成本');
disp('   取值: 大于等于1的实数，其中1表示无贸易成本，对角线元素应为1');
disp('   注意: 行列顺序必须与城市数据文件中的城市顺序一致');
disp(' ');

% 参数配置文件说明
disp('4. 参数配置文件');
disp('   路径: data/config/default_params.json');
disp('   格式: JSON文件');
disp('   必需参数:');
disp('     - model_params.beta: 折现因子（推荐值: 0.95）');
disp('     - model_params.psi: 跨期替代弹性（推荐值: 0.5）');
disp('     - model_params.delta: 折旧率（推荐值: 0.05）');
disp('     - model_params.theta: 贸易弹性（推荐值: 5）');
disp('     - model_params.epsilon: 资本替代弹性（推荐值: 4）');
disp('     - simulation_params.max_iter: 最大迭代次数（推荐值: 1000）');
disp('     - simulation_params.tol: 收敛容差（推荐值: 1e-8）');
disp(' ');

% 政策场景文件说明
disp('5. 政策场景文件');
disp('   路径: data/config/policy_scenarios/*.json');
disp('   格式: JSON文件');
disp('   必需参数:');
disp('     - tax: 各城市税收负担向量（C×1）');
disp('     - tau_change: 贸易成本变化倍数矩阵（C×C或单一值）');
disp('     - T_announce: 政策宣布时期');
disp('     - T_implement: 政策实施时期');
disp(' ');

% 数据准备建议
disp('数据准备建议:');
disp('1. 确保所有数据文件使用相同的城市顺序');
disp('2. 贸易矩阵和贸易成本矩阵必须是方阵，且维度与城市数量一致');
disp('3. 贸易成本矩阵中，对角线元素应为1（表示城市内部无贸易成本）');
disp('4. 如果缺少某些数据，模型会使用合理的默认值，但可能影响结果准确性');
disp('5. 可以参考data/raw目录下的示例文件了解正确的格式');
disp('6. 对于包含空格的路径，请确保使用char()函数处理文件路径');
disp('======================================================================');

% 检查必要的数据文件是否存在
city_data_file = fullfile(project_root, 'data', 'raw', 'city_data.csv');
trade_data_file = fullfile(project_root, 'data', 'raw', 'trade_matrix.csv');
trade_cost_file = fullfile(project_root, 'data', 'raw', 'trade_cost_matrix.csv');
params_file = fullfile(project_root, 'data', 'config', 'default_params.json');

missing_files = {};
if ~exist(char(city_data_file), 'file')
    missing_files{end+1} = 'city_data.csv';
end
if ~exist(char(trade_data_file), 'file')
    missing_files{end+1} = 'trade_matrix.csv';
end
if ~exist(char(trade_cost_file), 'file')
    missing_files{end+1} = 'trade_cost_matrix.csv';
end
if ~exist(char(params_file), 'file')
    missing_files{end+1} = 'default_params.json';
end

if ~isempty(missing_files)
    warning('缺少以下必要数据文件: %s', strjoin(missing_files, ', '));
    disp('请准备这些文件后再运行模型。');
else
    disp('所有必要的数据文件已找到。');
end 