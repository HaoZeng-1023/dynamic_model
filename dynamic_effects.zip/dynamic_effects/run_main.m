%% 城市间动态一般均衡模型 - 主程序
% 此脚本是模型的主入口，用于运行完整的模型分析

% 运行环境配置（如未运行）
if ~exist('project_root', 'var')
    run('setup.m');
end

%% 参数设置
% 定义输入文件路径
data_file = fullfile(project_root, 'data', 'config', 'default_params.json');
city_data_file = fullfile(project_root, 'data', 'raw', 'city_data.csv');
trade_data_file = fullfile(project_root, 'data', 'raw', 'trade_matrix.csv');
trade_cost_file = fullfile(project_root, 'data', 'raw', 'trade_cost_matrix.csv');
policy_file = fullfile(project_root, 'data', 'config', 'policy_scenarios', 'policy.json');

% 显示文件路径以便调试
disp('使用以下文件路径:');
disp(['数据文件: ', char(data_file)]);
disp(['城市数据: ', char(city_data_file)]);
disp(['贸易矩阵: ', char(trade_data_file)]);
disp(['贸易成本矩阵: ', char(trade_cost_file)]);
disp(['政策文件: ', char(policy_file)]);

% 检查文件是否存在
if ~exist(char(city_data_file), 'file')
    error('城市数据文件不存在: %s', city_data_file);
end
if ~exist(char(trade_data_file), 'file')
    error('贸易矩阵文件不存在: %s', trade_data_file);
end
if ~exist(char(trade_cost_file), 'file')
    error('贸易成本矩阵文件不存在: %s', trade_cost_file);
end

% 创建数据加载器
dataLoader = DataLoader();

% 加载数据
try
    [params, city_data, bilateral_data] = dataLoader.loadData(char(data_file), char(city_data_file), char(trade_data_file), char(trade_cost_file));
    policy = dataLoader.loadPolicy(char(policy_file));
catch e
    disp('数据加载错误:');
    disp(e.message);
    rethrow(e);
end

% 验证参数
paramValidator = ParameterValidator();
if ~paramValidator.validate(params, city_data, bilateral_data, policy)
    error('参数验证失败，请检查输入数据');
end

%% 初始化模型组件
tradeModel = Trade();
capitalModel = Capital();
householdModel = Household();
productionModel = Production();

%% 构建初始份额矩阵
shares = tradeModel.constructShares(bilateral_data, city_data);

%% 求解稳态
steadySolver = SteadyStateSolver();
[steady_state, converged] = steadySolver.solve(params, city_data, shares);

% 提取稳态变量
w0 = steady_state.w;
r0 = steady_state.r;
v0 = steady_state.v;
a0 = steady_state.a;

% 显示收敛信息
if converged
    disp('稳态求解已收敛');
else
    warning('稳态求解未收敛，结果可能不准确');
end

%% 构建动态系统
dynamicSolver = DynamicSolver();
[Psi, Gamma, Theta, Pi] = dynamicSolver.constructDynamicMatrices(params, shares, city_data);
[P, R] = dynamicSolver.solveTransitionMatrix(Psi, Gamma, Theta, Pi);

%% 计算政策冲击
shock = dynamicSolver.computePolicyShock(policy, params, shares);

%% 求解转移路径
T_max = 200;  % 最大期数
trajectory = dynamicSolver.computeTransitionPath(P, R, shock, params, steady_state, T_max);

%% 计算福利效应
welfareCalculator = WelfareCalculator();
welfare = welfareCalculator.computeWelfare(trajectory, params, steady_state);

%% 整理输出结果
results = struct();
results.steady_state = steady_state;
results.trajectory = trajectory;
results.welfare = welfare;
results.transition_matrix = P;

%% 生成报告
reportGenerator = ReportGenerator();

% 生成报告
reportGenerator.generateReport(results.steady_state, results.trajectory, results.welfare, city_data, params, policy);

%% 可视化结果
plotTrajectory = PlotTrajectory();
plotTrajectory.plotWealthPath(trajectory, city_data);
plotTrajectory.plotConsumptionPath(trajectory, city_data);

mapVisualizer = MapVisualizer();
mapVisualizer.plotWelfare(welfare, city_data);

%% 保存结果
save(fullfile(project_root, 'results', 'model_results.mat'), 'results', 'params', 'city_data', 'bilateral_data', 'policy');

disp('模型运行完成！');
disp(['结果已保存到: ', fullfile(project_root, 'results', 'model_results.mat')]);
disp(['报告已生成到: ', fullfile(project_root, 'results', 'reports')]); 