classdef DynamicSolver < handle
    % DynamicSolver 实现经济系统动态转移路径求解的类
    %   该类提供了构建和求解动态系统矩阵、计算政策冲击及转移路径的方法
    
    properties
        tol = 1e-10;  % 求解特征值问题的容差
    end
    
    methods
        function [Psi, Gamma, Theta, Pi] = constructDynamicMatrices(obj, params, shares, city_data)
            % constructDynamicMatrices 构建动态系统的线性化系数矩阵
            %
            % 输入参数:
            %   params - 模型参数结构体
            %   shares - 份额矩阵结构体
            %   city_data - 城市特征数据结构体
            %
            % 输出参数:
            %   Psi - 财富t+2项系数矩阵
            %   Gamma - 财富t+1项系数矩阵
            %   Theta - 财富t项系数矩阵
            %   Pi - 外生冲击系数矩阵
            
            C = params.C;
            beta = params.beta;
            delta = params.delta;
            psi = params.psi;
            epsilon = params.epsilon;
            theta = params.theta;
            
            % 提取份额矩阵
            S = shares.S;
            T = shares.T;
            B = shares.B;
            X = shares.X;
            
            % 财富份额
            xi = (1 - beta) * (1 - city_data.mu) ./ (1 - beta + city_data.mu * delta * beta);
            
            % 构建辅助矩阵
            D_xi = diag(xi);
            D_mu = diag(city_data.mu);
            I = eye(C);
            
            % 影响矩阵
            A_w = (I - T * (I - D_xi)) - theta * (T*S - I) * D_mu;
            B_w = T * D_xi * B + theta * (T*S - I) * (I - D_mu);
            C_w = T * D_xi;
            
            A_r = I + (epsilon - 1) * (I - X*B);
            B_r = X;
            
            % 求解L矩阵
            L_r = -inv(A_r) * B_r;
            L_w = inv(A_w) * (C_w + B_w * L_r);
            L_v = B * L_r;
            L_p = S * (D_mu * L_w + (I - D_mu) * L_r);
            
            % 构建动态系数矩阵
            Psi = -beta * D_xi;
            
            Gamma = -(1 + beta) * D_xi + (1 - beta) * psi * (1 - beta + beta*delta) * ...
                    (L_v - L_p) + D_xi * (1 - beta + beta*delta) * (L_v - L_p);
            
            Theta = D_xi + (I - D_xi) * (1 - beta) * (L_w - L_p) - ...
                    D_xi * (1 - beta + beta*delta) * (L_v - L_p);
            
            % 冲击影响矩阵（简化版本，仅考虑贸易成本冲击）
            Pi = (1 - beta) * psi * (1 - beta + beta*delta) * S;
        end
        
        function [P, R] = solveTransitionMatrix(obj, Psi, Gamma, Theta, Pi)
            % solveTransitionMatrix 求解转移矩阵
            %
            % 输入参数:
            %   Psi - 财富t+2项系数矩阵
            %   Gamma - 财富t+1项系数矩阵
            %   Theta - 财富t项系数矩阵
            %   Pi - 外生冲击系数矩阵
            %
            % 输出参数:
            %   P - 财富动态转移矩阵
            %   R - 冲击影响矩阵
            
            % 将二阶差分方程转化为一阶系统
            C = size(Psi, 1);
            
            % 构建增广系统
            Xi = [Gamma, Theta; eye(C), zeros(C)];
            Delta = [Psi, zeros(C); zeros(C), eye(C)];
            
            % 求解广义特征值问题
            [V, D] = eig(Xi, Delta);
            eigenvalues = diag(D);
            
            % 选择稳定的特征值（绝对值小于1）
            stable_idx = abs(eigenvalues) < 1;
            
            % 如果没有足够的稳定特征值，可能需要容差调整
            if sum(stable_idx) < C
                warning('稳定特征值数量不足，调整容差');
                stable_idx = abs(eigenvalues) < (1 + obj.tol);
            end
            
            % 提取对应的特征向量
            V_stable = V(:, stable_idx);
            V1 = V_stable(1:C, :);
            V2 = V_stable(C+1:end, :);
            
            % 转移矩阵
            P = V1 / V2;
            
            % 影响矩阵
            R = inv(Psi * P + Psi - Gamma) * Pi;
        end
        
        function shock = computePolicyShock(obj, policy, params, shares)
            % computePolicyShock 计算政策冲击
            %
            % 输入参数:
            %   policy - 政策参数结构体
            %   params - 模型参数结构体
            %   shares - 份额矩阵结构体
            %
            % 输出参数:
            %   shock - 冲击结构体
            
            C = params.C;
            
            % 初始财富冲击（税收）
            if isfield(policy, 'tax')
                wealth_shock = -policy.tax;  % 负值表示财富减少
            else
                wealth_shock = zeros(C, 1);
            end
            
            % 贸易成本冲击（对数变化）
            if isfield(policy, 'tau_change')
                tau_shock = log(policy.tau_change);  % C×C矩阵
            else
                tau_shock = zeros(C, C);
            end
            
            % 聚合贸易冲击（使用初始贸易份额加权）
            tau_in = sum(shares.S .* tau_shock, 2);  % 进口加权
            tau_out = sum(shares.T' .* tau_shock', 2);  % 出口加权
            
            shock = struct();
            shock.wealth = wealth_shock;
            shock.tau_in = tau_in;
            shock.tau_out = tau_out;
            shock.tau_shock = tau_shock;
            
            % 政策时间
            if isfield(policy, 'T_announce')
                shock.T_announce = policy.T_announce;
            else
                shock.T_announce = 0;
            end
            
            if isfield(policy, 'T_implement')
                shock.T_implement = policy.T_implement;
            else
                shock.T_implement = 1;
            end
        end
        
        function trajectory = computeTransitionPath(obj, P, R, shock, params, steady_state, T_max)
            % computeTransitionPath 计算转移路径
            %
            % 输入参数:
            %   P - 财富动态转移矩阵
            %   R - 冲击影响矩阵
            %   shock - 冲击结构体
            %   params - 模型参数结构体
            %   steady_state - 稳态结果结构体
            %   T_max - 最大期数
            %
            % 输出参数:
            %   trajectory - 转移路径结构体
            
            C = params.C;
            T_implement = shock.T_implement;
            
            % 初始化 (对数偏离)
            a_tilde = zeros(C, T_max);
            
            % t=0时的立即效应（税收）
            a_tilde(:, 1) = shock.wealth;
            
            % 计算预期效应
            for t = 2:T_max
                if t <= T_implement
                    % 政策尚未实施，仅有预期效应
                    a_tilde(:, t) = P * a_tilde(:, t-1);
                else
                    % 政策已实施
                    if t == T_implement + 1
                        % 实施时的跳跃
                        a_tilde(:, t) = P * a_tilde(:, t-1) + R * shock.tau_in;
                    else
                        % 后续演化
                        a_tilde(:, t) = P * a_tilde(:, t-1);
                    end
                end
            end
            
            % 计算财富的绝对水平
            a = steady_state.a .* exp(a_tilde);
            
            % 使用线性近似关系计算其他变量的路径
            % 这里需要从动态系统推导出L矩阵
            % 简化处理：使用稳态比例关系
            K = zeros(C, T_max);
            w = zeros(C, T_max);
            r = zeros(C, T_max);
            c = zeros(C, T_max);
            GDP = zeros(C, T_max);
            
            for t = 1:T_max
                % 假设资本与财富比例与稳态相同
                K(:, t) = a(:, t) .* (steady_state.K ./ steady_state.a);
                
                % 假设劳动收入与财富比例与稳态相同
                labor_income_t = a(:, t) .* (steady_state.labor_income ./ steady_state.a);
                
                % 工资
                w(:, t) = labor_income_t ./ steady_state.w;
                
                % GDP
                GDP(:, t) = labor_income_t ./ params.city_data.mu;
                
                % 资本租金
                capital_income_t = (1 - params.city_data.mu) .* GDP(:, t);
                r(:, t) = capital_income_t ./ K(:, t);
                
                % 消费
                c(:, t) = GDP(:, t) - params.delta * K(:, t);
            end
            
            % 计算各变量对稳态的对数偏离
            c_tilde = log(c ./ steady_state.c);
            K_tilde = log(K ./ steady_state.K);
            w_tilde = log(w ./ steady_state.w);
            r_tilde = log(r ./ steady_state.r);
            GDP_tilde = log(GDP ./ steady_state.GDP);
            
            % 构建输出结构体
            trajectory = struct();
            trajectory.a = a;
            trajectory.a_tilde = a_tilde;
            trajectory.c = c;
            trajectory.c_tilde = c_tilde;
            trajectory.K = K;
            trajectory.K_tilde = K_tilde;
            trajectory.w = w;
            trajectory.w_tilde = w_tilde;
            trajectory.r = r;
            trajectory.r_tilde = r_tilde;
            trajectory.GDP = GDP;
            trajectory.GDP_tilde = GDP_tilde;
            trajectory.time = 0:(T_max-1);
        end
    end
end 