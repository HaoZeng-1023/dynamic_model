classdef EquilibriumSystem < handle
    % EquilibriumSystem 表示经济均衡系统的类
    %   该类定义了经济均衡条件和相关函数
    
    properties
        params      % 模型参数
        city_data   % 城市数据
        shares      % 份额矩阵
    end
    
    methods
        function obj = EquilibriumSystem(params, city_data, shares)
            % EquilibriumSystem 构造函数
            %
            % 输入参数:
            %   params - 模型参数结构体
            %   city_data - 城市特征数据结构体
            %   shares - 份额矩阵结构体
            
            obj.params = params;
            obj.city_data = city_data;
            obj.shares = shares;
        end
        
        function error = checkEquilibriumConditions(obj, w, r, v, a)
            % checkEquilibriumConditions 检查均衡条件
            %
            % 输入参数:
            %   w - 工资向量
            %   r - 资本租金率向量
            %   v - 资本收入率向量
            %   a - 财富向量
            %
            % 输出参数:
            %   error - 均衡条件误差向量
            
            C = obj.params.C;
            mu = obj.city_data.mu;
            S = obj.shares.S;
            T = obj.shares.T;
            B = obj.shares.B;
            X = obj.shares.X;
            
            % 1. 商品市场出清条件
            % w_i * l_i / mu_i = sum_n[ S_ni * (v_n * a_n + w_n * l_n) ]
            labor_income = w .* obj.city_data.pop;
            total_income = v .* a + labor_income;
            goods_market_eq = labor_income ./ mu - T * total_income;
            
            % 2. 资本市场出清条件
            % (1-mu_i) * w_i * l_i / mu_i = sum_n[ v_n * B_ni * a_n ]
            capital_income = (1 - mu) .* labor_income ./ mu;
            capital_payment = X * (v .* a);
            capital_market_eq = capital_income - capital_payment;
            
            % 3. 贸易份额条件（简化检查）
            trade = Trade();
            S_implied = trade.updateTradeShares(w, r, obj.params, obj.city_data, obj.shares);
            trade_share_eq = S - S_implied;
            
            % 4. 资本份额条件（简化检查）
            capital = Capital();
            [B_implied, v_implied] = capital.updateCapitalShares(r, obj.params, obj.shares);
            capital_share_eq = B - B_implied;
            capital_return_eq = v - v_implied;
            
            % 计算总误差（每个条件的最大绝对误差）
            error = [
                max(abs(goods_market_eq));
                max(abs(capital_market_eq));
                max(max(abs(trade_share_eq)));
                max(max(abs(capital_share_eq)));
                max(abs(capital_return_eq))
            ];
        end
        
        function [GDP, consumption, welfare] = computeWelfare(obj, w, r, v, a)
            % computeWelfare 计算福利
            %
            % 输入参数:
            %   w - 工资向量
            %   r - 资本租金率向量
            %   v - 资本收入率向量
            %   a - 财富向量
            %
            % 输出参数:
            %   GDP - 城市GDP向量
            %   consumption - 消费向量
            %   welfare - 福利向量（效用）
            
            mu = obj.city_data.mu;
            pop = obj.city_data.pop;
            delta = obj.params.delta;
            
            % 劳动收入
            labor_income = w .* pop;
            
            % GDP
            GDP = labor_income ./ mu;
            
            % 资本存量
            K = obj.shares.B' * a;
            
            % 消费
            consumption = GDP - delta * K;
            
            % 福利（对数效用）
            welfare = log(consumption);
        end
        
        function J = computeJacobian(obj, w, r, dh)
            % computeJacobian 计算雅可比矩阵
            %
            % 输入参数:
            %   w - 当前工资向量
            %   r - 当前资本租金率向量
            %   dh - 扰动步长
            %
            % 输出参数:
            %   J - 雅可比矩阵
            
            C = obj.params.C;
            
            % 初始均衡误差
            eq0 = obj.equilibriumError(w, r);
            n_eq = length(eq0);
            
            % 初始化雅可比矩阵
            J = zeros(n_eq, 2*C);
            
            % 对工资扰动
            for i = 1:C
                w_perturb = w;
                w_perturb(i) = w_perturb(i) * (1 + dh);
                eq_w = obj.equilibriumError(w_perturb, r);
                J(:, i) = (eq_w - eq0) / (w(i) * dh);
            end
            
            % 对资本租金率扰动
            for i = 1:C
                r_perturb = r;
                r_perturb(i) = r_perturb(i) * (1 + dh);
                eq_r = obj.equilibriumError(w, r_perturb);
                J(:, C+i) = (eq_r - eq0) / (r(i) * dh);
            end
        end
        
        function eq = equilibriumError(obj, w, r)
            % equilibriumError 计算均衡误差
            %
            % 输入参数:
            %   w - 工资向量
            %   r - 资本租金率向量
            %
            % 输出参数:
            %   eq - 均衡条件误差向量
            
            C = obj.params.C;
            R_ss = 1/obj.params.beta;
            v_over_p_ss = R_ss - 1 + obj.params.delta;
            
            % 计算价格指数
            steadyStateSolver = SteadyStateSolver();
            p = steadyStateSolver.computePriceIndex(w, r, obj.params, obj.city_data, obj.shares);
            
            % 计算资本收入率
            v = v_over_p_ss * p;
            
            % 通过稳态关系估计财富
            a = ones(C, 1);  % 初始化
            
            % 迭代几次估计财富
            for iter = 1:5
                % 从资本市场出清条件更新财富
                a_new = obj.shares.X' \ ((1 - obj.city_data.mu) .* (w .* obj.city_data.pop) ./ obj.city_data.mu ./ v);
                a = 0.5 * a + 0.5 * a_new;  % 阻尼更新
            end
            
            % 检查商品市场出清条件
            labor_income = w .* obj.city_data.pop;
            total_income = v .* a + labor_income;
            goods_market_eq = labor_income ./ obj.city_data.mu - obj.shares.T * total_income;
            
            % 检查资本市场出清条件
            capital_income = (1 - obj.city_data.mu) .* labor_income ./ obj.city_data.mu;
            capital_payment = obj.shares.X * (v .* a);
            capital_market_eq = capital_income - capital_payment;
            
            % 组合误差
            eq = [goods_market_eq; capital_market_eq];
        end
    end
end 