classdef WelfareCalculator < handle
    % WelfareCalculator 计算政策变化导致的福利效应
    %   该类计算转移路径下的福利变化，包括消费等价变化
    
    methods
        function welfare = computeWelfare(obj, trajectory, params, steady_state)
            % computeWelfare 计算福利效应
            %
            % 输入参数:
            %   trajectory - 转移路径结构体
            %   params - 模型参数结构体
            %   steady_state - 稳态结果结构体
            %
            % 输出参数:
            %   welfare - 福利结果结构体
            
            beta = params.beta;
            psi = params.psi;
            C = params.C;
            T_max = size(trajectory.c, 2);
            
            % 基准消费路径（保持稳态不变）
            c_baseline = repmat(steady_state.c, 1, T_max);
            
            % 政策变化后的消费路径
            c_counter = trajectory.c;
            
            % 计算效用流
            if abs(psi - 1) < 1e-6
                % 对数效用 (psi ≈ 1)
                u_baseline = log(c_baseline);
                u_counter = log(c_counter);
            else
                % CRRA效用
                u_baseline = (c_baseline.^(1-1/psi) - 1) / (1-1/psi);
                u_counter = (c_counter.^(1-1/psi) - 1) / (1-1/psi);
            end
            
            % 贴现因子
            discount = beta.^(0:T_max-1);
            
            % 计算贴现的效用和
            discounted_welfare_baseline = sum(u_baseline .* repmat(discount, C, 1), 2);
            discounted_welfare_counter = sum(u_counter .* repmat(discount, C, 1), 2);
            
            % 福利变化
            welfare_change = discounted_welfare_counter - discounted_welfare_baseline;
            
            % 消费等价变化
            if abs(psi - 1) < 1e-6
                % 对数效用
                lambda = exp(welfare_change * (1-beta)) - 1;
            else
                % CRRA效用
                lambda = ((1 + welfare_change * (1-beta) * (1-1/psi)).^(psi/(psi-1))) - 1;
            end
            
            % 过渡期福利
            transition_welfare = zeros(C, 1);
            for i = 1:C
                % 计算每个城市的福利变化路径
                welfare_path = u_counter(i,:) - u_baseline(i,:);
                
                % 使用累积和计算过渡期福利（按期折现）
                cumulative_welfare = cumsum(welfare_path .* discount);
                transition_welfare(i) = cumulative_welfare(end);
            end
            
            % 分解为预期效应和实现效应
            T_implement = min(50, T_max/2);  % 假设政策在第50期实施
            
            % 政策实施前的福利变化
            anticipation_welfare = zeros(C, 1);
            for i = 1:C
                welfare_path = u_counter(i,1:T_implement) - u_baseline(i,1:T_implement);
                anticipation_welfare(i) = sum(welfare_path .* discount(1:T_implement));
            end
            
            % 政策实施后的福利变化
            realization_welfare = transition_welfare - anticipation_welfare;
            
            % 构建福利结构体
            welfare = struct();
            welfare.total_change = welfare_change;
            welfare.consumption_equivalent = lambda;
            welfare.transition = transition_welfare;
            welfare.anticipation = anticipation_welfare;
            welfare.realization = realization_welfare;
            welfare.path = u_counter - u_baseline;
            
            % 加入人口加权的平均福利变化
            if isfield(params, 'city_data') && isfield(params.city_data, 'pop')
                pop = params.city_data.pop;
                welfare.weighted_avg = sum(lambda .* pop) / sum(pop);
            else
                welfare.weighted_avg = mean(lambda);
            end
        end
        
        function decomposed = decomposeWelfare(obj, trajectory, params, steady_state)
            % decomposeWelfare 分解福利变化来源
            %
            % 输入参数:
            %   trajectory - 转移路径结构体
            %   params - 模型参数结构体
            %   steady_state - 稳态结果结构体
            %
            % 输出参数:
            %   decomposed - 分解后的福利结构体
            
            % 分解为不同来源的福利效应
            % 1. 劳动收入变化
            % 2. 资本收入变化
            % 3. 价格指数变化
            
            C = params.C;
            
            % 计算初始稳态下的各项贡献
            labor_income_ss = steady_state.labor_income;
            capital_income_ss = steady_state.capital_income;
            price_index_ss = steady_state.p;
            
            % 选取特定时期（例如最终时期）的变化
            T_final = size(trajectory.c, 2);
            
            % 假设我们能够从轨迹中获取这些变量
            labor_income_final = trajectory.w(:,T_final) .* params.city_data.pop;
            capital_income_final = trajectory.r(:,T_final) .* trajectory.K(:,T_final);
            price_index_final = price_index_ss .* exp(trajectory.p_tilde(:,T_final));
            
            % 计算对数变化
            d_labor = log(labor_income_final ./ labor_income_ss);
            d_capital = log(capital_income_final ./ capital_income_ss);
            d_price = -log(price_index_final ./ price_index_ss); % 注意价格下降为正福利
            
            % 总变化
            d_total = d_labor + d_capital + d_price;
            
            % 构建分解结构
            decomposed = struct();
            decomposed.labor_income = d_labor;
            decomposed.labor_share = d_labor ./ d_total;
            decomposed.capital_income = d_capital;
            decomposed.capital_share = d_capital ./ d_total;
            decomposed.price_index = d_price;
            decomposed.price_share = d_price ./ d_total;
            decomposed.total = d_total;
        end
    end
end 