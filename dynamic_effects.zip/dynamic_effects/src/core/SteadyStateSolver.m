classdef SteadyStateSolver < handle
    % SteadyStateSolver 实现经济系统稳态求解的类
    %   该类提供了求解城市间动态一般均衡模型稳态的方法
    
    properties
        max_iter = 1000;  % 最大迭代次数
        tol = 1e-8;       % 收敛容差
        damping = 0.5;    % 阻尼系数
    end
    
    methods
        function [steady_state, converged] = solve(obj, params, city_data, shares)
            % solve 求解经济系统的稳态
            %
            % 输入参数:
            %   params - 模型参数结构体
            %   city_data - 城市特征数据结构体
            %   shares - 份额矩阵结构体
            %
            % 输出参数:
            %   steady_state - 稳态结果结构体
            %   converged - 是否收敛的标志
            
            C = params.C;
            
            % 初始化
            w = ones(C, 1);  % 工资
            r = ones(C, 1);  % 资本租金率
            v = ones(C, 1);  % 资本收入率
            a = ones(C, 1);  % 财富
            
            % 稳态时的实际回报率
            R_ss = 1/params.beta;
            
            % 稳态时的资本收入率（实际）
            v_over_p_ss = R_ss - 1 + params.delta;
            
            converged = false;
            
            for iter = 1:obj.max_iter
                w_old = w;
                
                % 步骤1：给定w和r，更新贸易份额S
                trade = Trade();
                S_new = trade.updateTradeShares(w, r, params, city_data, shares);
                shares.S = S_new;
                
                % 步骤2：给定w和r，更新资本份额B和资本收入率v
                capital = Capital();
                [B_new, v_new] = capital.updateCapitalShares(r, params, shares);
                shares.B = B_new;
                
                % 步骤3：计算价格指数p
                p = obj.computePriceIndex(w, r, params, city_data, shares);
                
                % 步骤4：使用稳态条件 v/p = constant
                v = v_over_p_ss * p;
                
                % 步骤5：从市场出清条件更新w和r
                % 劳动收入 = mu * 总支出
                labor_income = city_data.mu .* shares.T * (v.*a + w.*city_data.pop);
                w_new = labor_income ./ city_data.pop;
                
                % 资本收入 = (1-mu) * 总产出
                capital_income = (1 - city_data.mu) .* labor_income ./ city_data.mu;
                total_capital_payment = shares.X * (v.*a);
                
                % 步骤6：更新财富（稳态条件）
                a = total_capital_payment / v_over_p_ss;
                
                % 步骤7：更新资本租金率
                K = shares.B' * a;  % 各城市资本存量
                r_new = capital_income ./ K;
                
                % 归一化（保持GDP=1）
                scale = sum(labor_income ./ city_data.mu);
                w_new = w_new / scale;
                r_new = r_new / scale;
                
                % 阻尼更新
                w = obj.damping * w + (1 - obj.damping) * w_new;
                r = obj.damping * r + (1 - obj.damping) * r_new;
                
                % 检查收敛
                if max(abs(w - w_old)) < obj.tol
                    converged = true;
                    break;
                end
            end
            
            % 计算最终稳态下的所有变量
            K = shares.B' * a;
            p = obj.computePriceIndex(w, r, params, city_data, shares);
            GDP = labor_income ./ city_data.mu;
            consumption = GDP - params.delta * K;
            
            % 构建输出结构体
            steady_state = struct();
            steady_state.w = w;
            steady_state.r = r;
            steady_state.v = v;
            steady_state.a = a;
            steady_state.K = K;
            steady_state.p = p;
            steady_state.GDP = GDP;
            steady_state.c = consumption;
            steady_state.labor_income = labor_income;
            steady_state.capital_income = capital_income;
            steady_state.welfare = log(consumption);  % 稳态福利 (对数效用)
        end
        
        function p = computePriceIndex(obj, w, r, params, city_data, shares)
            % computePriceIndex 计算价格指数
            %
            % 输入参数:
            %   w - 各城市工资向量
            %   r - 各城市资本租金率向量
            %   params - 模型参数结构体
            %   city_data - 城市特征数据结构体
            %   shares - 份额矩阵结构体
            %
            % 输出参数:
            %   p - 各城市价格指数向量
            
            C = params.C;
            theta = params.theta;
            mu = city_data.mu;
            S = shares.S;
            
            % 计算单位成本 (w^mu * r^(1-mu))
            unit_cost = w.^mu .* r.^(1-mu);
            
            % 假设存在贸易成本tau (从S反推)
            tau = ones(C, C);  % 初始假设为单位矩阵
            
            % 使用CES价格指数公式
            p = zeros(C, 1);
            for i = 1:C
                price_terms = S(i,:)'.^(-1/theta) .* unit_cost;
                p(i) = sum(price_terms)^(-1/theta);
            end
        end
    end
end 