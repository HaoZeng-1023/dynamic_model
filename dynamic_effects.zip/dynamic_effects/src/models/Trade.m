classdef Trade < handle
    % Trade 实现贸易模型的类
    %   该类包含与贸易份额和贸易成本相关的方法
    
    methods
        function shares = constructShares(obj, bilateral_data, city_data)
            % constructShares 从观测数据构建初始份额矩阵
            %
            % 输入参数:
            %   bilateral_data - 双边矩阵数据结构体
            %   city_data - 城市特征数据结构体
            %
            % 输出参数:
            %   shares - 份额矩阵结构体
            
            C = length(city_data.pop);
            
            % 构建贸易份额矩阵S
            % S_ni = E_ni / sum_h(E_nh)
            E = bilateral_data.trade_flow;  % C×C矩阵
            row_sum = sum(E, 2);  % 各行之和
            
            % 处理行和为零的情况
            zero_rows = (row_sum == 0);
            if any(zero_rows)
                warning('存在贸易总支出为零的城市，将使用均匀分布');
                % 设置为均匀分布
                for i = find(zero_rows)'
                    E(i,:) = ones(1,C) / C;
                end
                row_sum(zero_rows) = 1;
            end
            
            S = E ./ repmat(row_sum, 1, C);
            
            % 构建贸易收入份额矩阵T
            % T_in = E_ni / sum_h(E_hi)
            col_sum = sum(E, 1);  % 各列之和
            
            % 处理列和为零的情况
            zero_cols = (col_sum == 0);
            if any(zero_cols)
                warning('存在贸易总收入为零的城市，将使用均匀分布');
                % 设置为均匀分布
                for j = find(zero_cols)
                    E(:,j) = ones(C,1) / C;
                end
                col_sum(zero_cols) = 1;
            end
            
            T = E ./ repmat(col_sum, C, 1);
            
            % 构建资本份额矩阵（如无数据，使用贸易份额近似）
            % 这里假设资本份额与贸易份额有相似的地理分布模式
            B = S;  % 初始假设
            X = T;  % 初始假设
            
            shares = struct();
            shares.S = S;
            shares.T = T;
            shares.B = B;
            shares.X = X;
            
            % 输出份额矩阵的基本信息
            disp('贸易份额矩阵构建完成:');
            disp(['S矩阵均值: ', num2str(mean(S(:)))]);
            disp(['T矩阵均值: ', num2str(mean(T(:)))]);
        end
        
        function tau = estimateTradeBarriers(obj, shares, city_data, params, bilateral_data)
            % estimateTradeBarriers 估算贸易障碍
            %
            % 输入参数:
            %   shares - 份额矩阵结构体
            %   city_data - 城市特征数据结构体
            %   params - 模型参数结构体
            %   bilateral_data - 双边矩阵数据结构体
            %
            % 输出参数:
            %   tau - 贸易成本矩阵
            
            C = params.C;
            theta = params.theta;
            S = shares.S;
            
            % 初始化贸易成本矩阵
            tau = ones(C, C);
            
            % 如果有直接的贸易成本数据，优先使用
            if ~isempty(bilateral_data) && isfield(bilateral_data, 'trade_cost')
                tau = bilateral_data.trade_cost;
                
                % 确保对角线元素为1（自身无贸易成本）
                for i = 1:C
                    tau(i, i) = 1;
                end
                
                % 调整为与theta相容的形式
                tau = tau.^theta;
                return;
            end
            
            % 如果没有直接的贸易成本数据，通过Head-Ries指数估算
            for i = 1:C
                for j = 1:C
                    if i ~= j
                        % Head-Ries指数 tau_ij = sqrt((S_ij * S_ji) / (S_ii * S_jj))
                        % 通常贸易成本随距离增加，但也受制度、语言等因素影响
                        tau(i, j) = sqrt((S(i,j) * S(j,i)) / (S(i,i) * S(j,j)));
                        
                        % 处理极端情况
                        if isnan(tau(i, j)) || tau(i, j) <= 0
                            tau(i, j) = 2.0;  % 默认值
                        end
                    end
                end
            end
            
            % 对角线元素为1（自身无贸易成本）
            for i = 1:C
                tau(i, i) = 1;
            end
            
            % 调整为与theta相容的形式
            tau = tau.^theta;
        end
        
        function S_new = updateTradeShares(obj, w, r, params, city_data, shares)
            % updateTradeShares 更新贸易份额
            %
            % 输入参数:
            %   w - 工资向量
            %   r - 资本租金率向量
            %   params - 模型参数结构体
            %   city_data - 城市特征数据结构体
            %   shares - 份额矩阵结构体
            %
            % 输出参数:
            %   S_new - 更新后的贸易份额矩阵
            
            C = params.C;
            theta = params.theta;
            mu = city_data.mu;
            
            % 估计贸易成本
            tau = obj.estimateTradeBarriers(shares, city_data, params, []);
            
            % 计算单位成本（假设生产率z=1）
            unit_cost = w.^mu .* r.^(1-mu);
            
            % 构建贸易成本调整后的成本矩阵
            cost_matrix = zeros(C, C);
            for i = 1:C
                for j = 1:C
                    cost_matrix(i, j) = tau(i, j) * unit_cost(j);
                end
            end
            
            % 计算贸易份额
            % S_ni = (tau_ni * c_i)^(-theta) / sum_h((tau_nh * c_h)^(-theta))
            cost_matrix_neg_theta = cost_matrix.^(-theta);
            denom = sum(cost_matrix_neg_theta, 2);
            S_new = cost_matrix_neg_theta ./ repmat(denom, 1, C);
            
            % 处理数值问题
            S_new(isnan(S_new)) = 0;
            
            % 确保每行之和为1
            row_sum = sum(S_new, 2);
            S_new = S_new ./ repmat(row_sum, 1, C);
        end
        
        function price_index = computePriceIndex(obj, w, r, tau, params, city_data)
            % computePriceIndex 计算价格指数
            %
            % 输入参数:
            %   w - 工资向量
            %   r - 资本租金率向量
            %   tau - 贸易成本矩阵
            %   params - 模型参数结构体
            %   city_data - 城市特征数据结构体
            %
            % 输出参数:
            %   price_index - 价格指数向量
            
            C = params.C;
            theta = params.theta;
            mu = city_data.mu;
            
            % 计算单位成本
            unit_cost = w.^mu .* r.^(1-mu);
            
            % 计算价格指数（CES价格公式）
            price_index = zeros(C, 1);
            for i = 1:C
                price_terms = tau(i, :)'.^(-theta) .* unit_cost.^(-theta);
                price_index(i) = sum(price_terms).^(-1/theta);
            end
        end
        
        function S_new = applyPolicyShock(obj, S_old, tau_change, params)
            % applyPolicyShock 应用贸易成本冲击
            %
            % 输入参数:
            %   S_old - 原始贸易份额矩阵
            %   tau_change - 贸易成本变化倍数矩阵
            %   params - 模型参数结构体
            %
            % 输出参数:
            %   S_new - 冲击后的贸易份额矩阵
            
            C = params.C;
            theta = params.theta;
            
            % 计算贸易成本变化的影响
            impact = tau_change.^(-theta);
            
            % 调整贸易份额
            S_temp = S_old .* impact;
            
            % 重新归一化
            row_sum = sum(S_temp, 2);
            S_new = S_temp ./ repmat(row_sum, 1, C);
            
            % 处理数值问题
            S_new(isnan(S_new)) = 0;
            S_new(isinf(S_new)) = 1;
            
            % 确保每行之和为1
            row_sum = sum(S_new, 2);
            S_new = S_new ./ repmat(row_sum, 1, C);
        end
    end
end 