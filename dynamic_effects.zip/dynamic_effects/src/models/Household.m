classdef Household < handle
    % Household 实现家庭部门模型的类
    %   该类包含与家庭消费、储蓄和效用相关的方法
    
    methods
        function c = computeConsumption(obj, GDP, I, params)
            % computeConsumption 计算消费
            %
            % 输入参数:
            %   GDP - GDP向量
            %   I - 投资向量
            %   params - 模型参数结构体
            %
            % 输出参数:
            %   c - 消费向量
            
            % 消费 = GDP - 投资
            c = GDP - I;
        end
        
        function I = computeInvestment(obj, K, K_next, params)
            % computeInvestment 计算投资
            %
            % 输入参数:
            %   K - 当前资本存量向量
            %   K_next - 下期资本存量向量
            %   params - 模型参数结构体
            %
            % 输出参数:
            %   I - 投资向量
            
            % 投资 = 下期资本 - (1-折旧率) * 当前资本
            I = K_next - (1 - params.delta) * K;
        end
        
        function a_next = computeWealthDynamics(obj, a, c, v, w, pop, params)
            % computeWealthDynamics 计算财富动态
            %
            % 输入参数:
            %   a - 当前财富向量
            %   c - 消费向量
            %   v - 资本收入率向量
            %   w - 工资向量
            %   pop - 人口向量
            %   params - 模型参数结构体
            %
            % 输出参数:
            %   a_next - 下期财富向量
            
            % 总收入 = 劳动收入 + 资本收入
            labor_income = w .* pop;
            capital_income = v .* a;
            total_income = labor_income + capital_income;
            
            % 储蓄 = 总收入 - 消费
            saving = total_income - c;
            
            % 下期财富 = 储蓄 / 折现因子
            a_next = saving / params.beta;
        end
        
        function [euler_error, a_next] = checkEulerEquation(obj, a, a_next, c, c_next, v, v_next, params)
            % checkEulerEquation 检查欧拉方程
            %
            % 输入参数:
            %   a - 当前财富向量
            %   a_next - 下期财富向量
            %   c - 当前消费向量
            %   c_next - 下期消费向量
            %   v - 当前资本收入率向量
            %   v_next - 下期资本收入率向量
            %   params - 模型参数结构体
            %
            % 输出参数:
            %   euler_error - 欧拉方程误差
            %   a_next - 调整后的下期财富向量
            
            beta = params.beta;
            psi = params.psi;
            
            % 欧拉方程: c^(-1/psi) = beta * v_next/v * c_next^(-1/psi)
            lhs = c.^(-1/psi);
            rhs = beta * (v_next ./ v) .* c_next.^(-1/psi);
            
            euler_error = lhs - rhs;
            
            % 调整下期财富以减小欧拉方程误差
            % 简化处理：按照比例调整
            adjustment_factor = (lhs ./ rhs).^psi;
            a_next = a_next .* adjustment_factor;
        end
        
        function u = computeUtility(obj, c, params)
            % computeUtility 计算效用
            %
            % 输入参数:
            %   c - 消费向量
            %   params - 模型参数结构体
            %
            % 输出参数:
            %   u - 效用向量
            
            psi = params.psi;
            
            % CRRA效用函数
            if abs(psi - 1) < 1e-6  % psi接近1，使用对数效用
                u = log(c);
            else
                u = (c.^(1-1/psi) - 1) / (1-1/psi);
            end
        end
        
        function welfare = computePresentValueWelfare(obj, u_path, params)
            % computePresentValueWelfare 计算现值福利
            %
            % 输入参数:
            %   u_path - 效用路径矩阵（每行一个城市，每列一个时期）
            %   params - 模型参数结构体
            %
            % 输出参数:
            %   welfare - 现值福利向量
            
            beta = params.beta;
            T = size(u_path, 2);
            
            % 计算折现因子
            discount_factors = beta.^(0:T-1);
            
            % 计算贴现效用和
            welfare = u_path * discount_factors';
        end
        
        function lambda = computeConsumptionEquivalent(obj, welfare_base, welfare_policy, params)
            % computeConsumptionEquivalent 计算消费等价变化
            %
            % 输入参数:
            %   welfare_base - 基准情形下的福利向量
            %   welfare_policy - 政策情形下的福利向量
            %   params - 模型参数结构体
            %
            % 输出参数:
            %   lambda - 消费等价变化（百分比）
            
            beta = params.beta;
            psi = params.psi;
            
            % 福利变化
            delta_welfare = welfare_policy - welfare_base;
            
            % 计算等价变化
            if abs(psi - 1) < 1e-6  % 对数效用
                lambda = exp((1-beta) * delta_welfare) - 1;
            else
                lambda = ((1 + (1-beta) * (1-1/psi) * delta_welfare).^(psi/(psi-1))) - 1;
            end
            
            % 转换为百分比
            lambda = lambda * 100;
        end
        
        function [c_path, a_path] = solveForwardPath(obj, a0, w_path, v_path, r_path, pop, params, T)
            % solveForwardPath 求解前向路径
            %
            % 输入参数:
            %   a0 - 初始财富向量
            %   w_path - 工资路径矩阵
            %   v_path - 资本收入率路径矩阵
            %   r_path - 资本租金率路径矩阵
            %   pop - 人口向量
            %   params - 模型参数结构体
            %   T - 期数
            %
            % 输出参数:
            %   c_path - 消费路径矩阵
            %   a_path - 财富路径矩阵
            
            C = length(a0);
            beta = params.beta;
            delta = params.delta;
            
            % 初始化路径
            a_path = zeros(C, T);
            c_path = zeros(C, T);
            a_path(:,1) = a0;
            
            % 计算每期的消费和财富
            for t = 1:T
                % 当期收入
                labor_income = w_path(:,t) .* pop;
                capital_income = v_path(:,t) .* a_path(:,t);
                total_income = labor_income + capital_income;
                
                % 计算消费（使用稳态储蓄率近似）
                saving_rate = beta * (v_path(:,t) - delta) / (1 - beta + beta*delta);
                c_path(:,t) = (1 - saving_rate) .* total_income;
                
                % 更新下期财富
                if t < T
                    a_path(:,t+1) = (total_income - c_path(:,t)) / beta;
                end
            end
        end
    end
end 