classdef Capital < handle
    % Capital 实现资本市场模型的类
    %   该类包含与资本市场、资本份额和收入率相关的方法
    
    methods
        function [B_new, v_new] = updateCapitalShares(obj, r, params, shares)
            % updateCapitalShares 更新资本份额和资本收入率
            %
            % 输入参数:
            %   r - 资本租金率向量
            %   params - 模型参数结构体
            %   shares - 份额矩阵结构体
            %
            % 输出参数:
            %   B_new - 更新后的资本份额矩阵
            %   v_new - 更新后的资本收入率向量
            
            C = params.C;
            epsilon = params.epsilon;
            
            % 假设资本效率eta=1，投资成本kappa由资本份额推断
            
            % 估算投资成本矩阵
            kappa = obj.estimateInvestmentCosts(r, shares.B, epsilon);
            
            % 计算资本份额
            % B_ni = (r_i/kappa_ni)^epsilon / sum_h((r_h/kappa_nh)^epsilon)
            B_new = zeros(C, C);
            
            for n = 1:C
                for i = 1:C
                    if kappa(n, i) > 0
                        B_new(n, i) = (r(i) / kappa(n, i))^epsilon;
                    else
                        B_new(n, i) = 0;
                    end
                end
                
                % 归一化以确保每行和为1
                row_sum = sum(B_new(n, :));
                if row_sum > 0
                    B_new(n, :) = B_new(n, :) / row_sum;
                else
                    % 如果所有元素为零，设置为均匀分布
                    B_new(n, :) = ones(1, C) / C;
                end
            end
            
            % 计算资本收入率
            % v_n = gamma * [sum_h((r_h/kappa_nh)^epsilon)]^(1/epsilon)
            gamma = obj.gammaFunc(1 - 1/epsilon);
            v_new = zeros(C, 1);
            
            for n = 1:C
                sum_term = 0;
                for i = 1:C
                    if kappa(n, i) > 0
                        sum_term = sum_term + (r(i) / kappa(n, i))^epsilon;
                    end
                end
                v_new(n) = gamma * sum_term^(1/epsilon);
            end
            
            % 处理数值问题
            v_new(isnan(v_new)) = mean(v_new(~isnan(v_new)));
            if all(isnan(v_new))
                v_new = ones(C, 1);
            end
            
            % 确保B矩阵的每行之和为1
            for n = 1:C
                row_sum = sum(B_new(n, :));
                if row_sum > 0
                    B_new(n, :) = B_new(n, :) / row_sum;
                else
                    B_new(n, :) = ones(1, C) / C;
                end
            end
        end
        
        function kappa = estimateInvestmentCosts(obj, r, B, epsilon)
            % estimateInvestmentCosts 估算投资成本
            %
            % 输入参数:
            %   r - 资本租金率向量
            %   B - 资本份额矩阵
            %   epsilon - 资本替代弹性
            %
            % 输出参数:
            %   kappa - 投资成本矩阵
            
            [C, ~] = size(B);
            kappa = ones(C, C);
            
            % 对每个来源城市n
            for n = 1:C
                % 求出denominator: sum_j(B_nj^(1/epsilon) * r_j)
                denom = 0;
                for j = 1:C
                    if B(n, j) > 0
                        denom = denom + B(n, j)^(1/epsilon) * r(j);
                    end
                end
                
                % 计算每个目的地城市i的投资成本
                for i = 1:C
                    if B(n, i) > 0 && denom > 0
                        kappa(n, i) = r(i) / (denom * B(n, i)^(1/epsilon));
                    else
                        % 如果份额为零，设置为高成本
                        kappa(n, i) = max(r) * 100;
                    end
                end
            end
            
            % 处理极端情况
            kappa(kappa <= 0) = max(r) * 100;
            kappa(isinf(kappa)) = max(r) * 100;
            kappa(isnan(kappa)) = max(r) * 100;
        end
        
        function gamma_val = gammaFunc(obj, x)
            % gammaFunc 计算gamma函数值
            %
            % 输入参数:
            %   x - 函数参数
            %
            % 输出参数:
            %   gamma_val - gamma函数值
            
            % 对于epsilon=4，gamma函数值约为0.906
            if x <= 0 || x >= 1
                gamma_val = 0.906;  % 默认值
            else
                % 使用MATLAB内置的gamma函数
                gamma_val = gamma(x);
            end
        end
        
        function K = computeCapitalStock(obj, B, a)
            % computeCapitalStock 计算资本存量
            %
            % 输入参数:
            %   B - 资本份额矩阵
            %   a - 财富向量
            %
            % 输出参数:
            %   K - 资本存量向量
            
            % 资本存量是各城市投入该地的资本总和
            K = B' * a;
        end
        
        function capital_income = computeCapitalIncome(obj, r, K)
            % computeCapitalIncome 计算资本收入
            %
            % 输入参数:
            %   r - 资本租金率向量
            %   K - 资本存量向量
            %
            % 输出参数:
            %   capital_income - 资本收入向量
            
            capital_income = r .* K;
        end
        
        function [B_new, v_new] = applyPolicyShock(obj, B_old, v_old, policy, params)
            % applyPolicyShock 应用政策冲击到资本市场
            %
            % 输入参数:
            %   B_old - 原始资本份额矩阵
            %   v_old - 原始资本收入率向量
            %   policy - 政策参数结构体
            %   params - 模型参数结构体
            %
            % 输出参数:
            %   B_new - 冲击后的资本份额矩阵
            %   v_new - 冲击后的资本收入率向量
            
            % 如果政策不影响资本市场，直接返回原始值
            B_new = B_old;
            v_new = v_old;
            
            % 处理资本市场政策（如减税、补贴等）
            if isfield(policy, 'capital_subsidy')
                % 简单处理：假设补贴降低了投资成本
                kappa_change = 1 - policy.capital_subsidy;
                
                C = params.C;
                epsilon = params.epsilon;
                
                % 估算原始投资成本
                r = ones(C, 1);  % 需要真实的r值
                kappa = obj.estimateInvestmentCosts(r, B_old, epsilon);
                
                % 应用补贴
                kappa = kappa .* repmat(kappa_change, C, 1);
                
                % 重新计算资本份额
                [B_new, v_new] = obj.updateCapitalSharesWithKappa(r, kappa, params);
            end
        end
        
        function [B_new, v_new] = updateCapitalSharesWithKappa(obj, r, kappa, params)
            % updateCapitalSharesWithKappa 给定投资成本更新资本份额
            %
            % 输入参数:
            %   r - 资本租金率向量
            %   kappa - 投资成本矩阵
            %   params - 模型参数结构体
            %
            % 输出参数:
            %   B_new - 更新后的资本份额矩阵
            %   v_new - 更新后的资本收入率向量
            
            C = params.C;
            epsilon = params.epsilon;
            
            % 计算资本份额
            B_new = zeros(C, C);
            for n = 1:C
                for i = 1:C
                    if kappa(n, i) > 0
                        B_new(n, i) = (r(i) / kappa(n, i))^epsilon;
                    end
                end
                
                % 归一化
                row_sum = sum(B_new(n, :));
                if row_sum > 0
                    B_new(n, :) = B_new(n, :) / row_sum;
                else
                    B_new(n, :) = ones(1, C) / C;
                end
            end
            
            % 计算资本收入率
            gamma = obj.gammaFunc(1 - 1/epsilon);
            v_new = zeros(C, 1);
            
            for n = 1:C
                sum_term = 0;
                for i = 1:C
                    if kappa(n, i) > 0
                        sum_term = sum_term + (r(i) / kappa(n, i))^epsilon;
                    end
                end
                v_new(n) = gamma * sum_term^(1/epsilon);
            end
        end
    end
end 