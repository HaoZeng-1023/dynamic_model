classdef Production < handle
    % Production 实现生产部门模型的类
    %   该类包含与生产、工资和资本租金率相关的方法
    
    methods
        function GDP = computeGDP(obj, w, pop, mu)
            % computeGDP 计算GDP
            %
            % 输入参数:
            %   w - 工资向量
            %   pop - 人口向量
            %   mu - 劳动份额向量
            %
            % 输出参数:
            %   GDP - GDP向量
            
            % 劳动收入
            labor_income = w .* pop;
            
            % GDP = 劳动收入 / 劳动份额
            GDP = labor_income ./ mu;
        end
        
        function [w, r] = computeFactorPrices(obj, city_data, K, params)
            % computeFactorPrices 计算要素价格
            %
            % 输入参数:
            %   city_data - 城市特征数据结构体
            %   K - 资本存量向量
            %   params - 模型参数结构体
            %
            % 输出参数:
            %   w - 工资向量
            %   r - 资本租金率向量
            
            mu = city_data.mu;
            pop = city_data.pop;
            GDP = city_data.GDP;
            
            % 计算资本租金率
            r = (1 - mu) .* GDP ./ K;
            
            % 计算工资率
            w = mu .* GDP ./ pop;
        end
        
        function unit_cost = computeUnitCost(obj, w, r, mu)
            % computeUnitCost 计算单位成本
            %
            % 输入参数:
            %   w - 工资向量
            %   r - 资本租金率向量
            %   mu - 劳动份额向量
            %
            % 输出参数:
            %   unit_cost - 单位成本向量
            
            % 单位成本 = w^mu * r^(1-mu)
            unit_cost = w.^mu .* r.^(1-mu);
        end
        
        function MPK = computeMPK(obj, GDP, K, mu)
            % computeMPK 计算资本边际产出
            %
            % 输入参数:
            %   GDP - GDP向量
            %   K - 资本存量向量
            %   mu - 劳动份额向量
            %
            % 输出参数:
            %   MPK - 资本边际产出向量
            
            % MPK = (1-mu) * GDP / K
            MPK = (1 - mu) .* GDP ./ K;
        end
        
        function MPL = computeMPL(obj, GDP, pop, mu)
            % computeMPL 计算劳动边际产出
            %
            % 输入参数:
            %   GDP - GDP向量
            %   pop - 人口向量
            %   mu - 劳动份额向量
            %
            % 输出参数:
            %   MPL - 劳动边际产出向量
            
            % MPL = mu * GDP / L
            MPL = mu .* GDP ./ pop;
        end
        
        function z = estimateProductivity(obj, GDP, K, pop, mu)
            % estimateProductivity 估算生产率
            %
            % 输入参数:
            %   GDP - GDP向量
            %   K - 资本存量向量
            %   pop - 人口向量
            %   mu - 劳动份额向量
            %
            % 输出参数:
            %   z - 生产率向量
            
            % 假设生产函数为 Y = z * K^(1-mu) * L^mu
            % 则 z = Y / (K^(1-mu) * L^mu)
            z = GDP ./ (K.^(1-mu) .* pop.^mu);
        end
        
        function [GDP_change, labor_share, capital_share] = decomposeGrowth(obj, GDP0, GDP1, K0, K1, pop0, pop1, z0, z1)
            % decomposeGrowth 分解增长来源
            %
            % 输入参数:
            %   GDP0 - 初始GDP向量
            %   GDP1 - 终期GDP向量
            %   K0 - 初始资本存量向量
            %   K1 - 终期资本存量向量
            %   pop0 - 初始人口向量
            %   pop1 - 终期人口向量
            %   z0 - 初始生产率向量
            %   z1 - 终期生产率向量
            %
            % 输出参数:
            %   GDP_change - GDP变化率向量
            %   labor_share - 劳动贡献份额向量
            %   capital_share - 资本贡献份额向量
            
            % GDP增长率
            GDP_change = GDP1 ./ GDP0 - 1;
            
            % 分解为资本、劳动和全要素生产率贡献
            K_change = K1 ./ K0 - 1;
            L_change = pop1 ./ pop0 - 1;
            z_change = z1 ./ z0 - 1;
            
            % 简化处理：使用对数近似
            GDP_growth = log(GDP1 ./ GDP0);
            K_contrib = (1 - 0.6) * log(K1 ./ K0);  % 假设资本份额为0.4
            L_contrib = 0.6 * log(pop1 ./ pop0);  % 假设劳动份额为0.6
            z_contrib = log(z1 ./ z0);
            
            % 计算份额
            total_contrib = K_contrib + L_contrib + z_contrib;
            capital_share = K_contrib ./ total_contrib;
            labor_share = L_contrib ./ total_contrib;
            tfp_share = z_contrib ./ total_contrib;
            
            % 处理零增长情况
            zero_growth = (abs(total_contrib) < 1e-10);
            capital_share(zero_growth) = 0;
            labor_share(zero_growth) = 0;
            
            % 确保所有份额之和为1
            sum_share = capital_share + labor_share + tfp_share;
            capital_share = capital_share ./ sum_share;
            labor_share = labor_share ./ sum_share;
        end
        
        function GDP = forecastGDP(obj, K, pop, mu, z)
            % forecastGDP 预测GDP
            %
            % 输入参数:
            %   K - 资本存量向量
            %   pop - 人口向量
            %   mu - 劳动份额向量
            %   z - 生产率向量
            %
            % 输出参数:
            %   GDP - 预测的GDP向量
            
            % 使用柯布-道格拉斯生产函数
            GDP = z .* K.^(1-mu) .* pop.^mu;
        end
    end
end 