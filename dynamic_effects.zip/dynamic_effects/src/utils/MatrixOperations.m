classdef MatrixOperations < handle
    % MatrixOperations 提供矩阵运算的辅助函数
    
    methods (Static)
        function normalization = rowNormalize(matrix)
            % rowNormalize 行归一化矩阵
            %
            % 输入参数:
            %   matrix - 待归一化的矩阵
            %
            % 输出参数:
            %   normalization - 行归一化后的矩阵
            
            row_sum = sum(matrix, 2);  % 各行之和
            
            % 处理行和为0的情况
            zero_rows = (row_sum == 0);
            if any(zero_rows)
                warning('存在行和为零的行，将设置为均匀分布');
                row_sum(zero_rows) = 1;
                
                % 零行设置为均匀分布
                n_cols = size(matrix, 2);
                for i = find(zero_rows)'
                    matrix(i, :) = ones(1, n_cols) / n_cols;
                end
            end
            
            normalization = matrix ./ repmat(row_sum, 1, size(matrix, 2));
        end
        
        function normalization = colNormalize(matrix)
            % colNormalize 列归一化矩阵
            %
            % 输入参数:
            %   matrix - 待归一化的矩阵
            %
            % 输出参数:
            %   normalization - 列归一化后的矩阵
            
            col_sum = sum(matrix, 1);  % 各列之和
            
            % 处理列和为0的情况
            zero_cols = (col_sum == 0);
            if any(zero_cols)
                warning('存在列和为零的列，将设置为均匀分布');
                col_sum(zero_cols) = 1;
                
                % 零列设置为均匀分布
                n_rows = size(matrix, 1);
                for j = find(zero_cols)
                    matrix(:, j) = ones(n_rows, 1) / n_rows;
                end
            end
            
            normalization = matrix ./ repmat(col_sum, size(matrix, 1), 1);
        end
        
        function shares = constructShares(trade_flow)
            % constructShares 从贸易流量构建份额矩阵
            %
            % 输入参数:
            %   trade_flow - 贸易流量矩阵 E_ni
            %
            % 输出参数:
            %   shares - 份额矩阵结构体
            
            % 贸易支出份额 S_ni = E_ni / sum_h(E_nh)
            S = MatrixOperations.rowNormalize(trade_flow);
            
            % 贸易收入份额 T_in = E_ni / sum_h(E_hi)
            T = MatrixOperations.colNormalize(trade_flow);
            
            % 构建输出结构
            shares = struct();
            shares.S = S;
            shares.T = T;
            
            % 初始化资本份额矩阵（假设与贸易份额相似）
            shares.B = S;
            shares.X = T;
        end
        
        function matrix = enforceSymmetry(matrix, method)
            % enforceSymmetry 强制矩阵对称
            %
            % 输入参数:
            %   matrix - 待对称化的矩阵
            %   method - 对称化方法: 'average', 'max', 'min'
            %
            % 输出参数:
            %   matrix - 对称化后的矩阵
            
            if nargin < 2
                method = 'average';
            end
            
            % 检查是否为方阵
            [m, n] = size(matrix);
            if m ~= n
                error('只能对方阵进行对称化处理');
            end
            
            % 对称化处理
            switch lower(method)
                case 'average'
                    % 上下三角平均
                    matrix = (matrix + matrix') / 2;
                case 'max'
                    % 取上下三角最大值
                    matrix = max(matrix, matrix');
                case 'min'
                    % 取上下三角最小值
                    matrix = min(matrix, matrix');
                otherwise
                    error('不支持的对称化方法: %s', method);
            end
        end
        
        function matrix = fillDiagonal(matrix, value)
            % fillDiagonal 填充矩阵对角线
            %
            % 输入参数:
            %   matrix - 待处理矩阵
            %   value - 对角线填充值
            %
            % 输出参数:
            %   matrix - 处理后的矩阵
            
            n = min(size(matrix));
            idx = 1:n+1:n*n;  % 对角线索引
            matrix(idx) = value;
        end
        
        function matrix = scaleMatrix(matrix, factor)
            % scaleMatrix 按比例缩放矩阵
            %
            % 输入参数:
            %   matrix - 待缩放矩阵
            %   factor - 缩放因子
            %
            % 输出参数:
            %   matrix - 缩放后的矩阵
            
            matrix = matrix * factor;
        end
        
        function res = softmax(x, temperature)
            % softmax 计算softmax函数
            %
            % 输入参数:
            %   x - 输入向量或矩阵
            %   temperature - 温度参数（默认为1）
            %
            % 输出参数:
            %   res - softmax结果
            
            if nargin < 2
                temperature = 1;
            end
            
            x_scaled = x / temperature;
            
            % 为防止上溢，减去每行的最大值
            x_max = max(x_scaled, [], 2);
            x_shifted = x_scaled - repmat(x_max, 1, size(x_scaled, 2));
            
            % 计算exp并归一化
            exp_x = exp(x_shifted);
            res = exp_x ./ repmat(sum(exp_x, 2), 1, size(exp_x, 2));
        end
        
        function gamma = gammaFunction(x)
            % gammaFunction 计算gamma函数值
            %
            % 输入参数:
            %   x - 输入值
            %
            % 输出参数:
            %   gamma - gamma函数结果
            
            gamma = gamma(x);
        end
    end
end 