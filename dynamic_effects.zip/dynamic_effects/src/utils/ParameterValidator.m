classdef ParameterValidator < handle
    % ParameterValidator 验证模型参数的合法性
    
    methods
        function isValid = validate(obj, params, city_data, bilateral_data, policy)
            % validate 验证所有输入参数
            %
            % 输入参数:
            %   params - 模型参数结构体
            %   city_data - 城市特征数据结构体
            %   bilateral_data - 双边矩阵数据结构体
            %   policy - 政策参数结构体
            %
            % 输出参数:
            %   isValid - 验证结果，true表示验证通过，false表示验证失败
            
            isValid = true;
            
            try
                obj.validateParams(params);
                obj.validateCityData(city_data, params.C);
                obj.validateBilateralData(bilateral_data, params.C);
                obj.validatePolicy(policy, params.C);
                
                % 验证参数与城市数据的一致性
                obj.validateConsistency(params, city_data, bilateral_data);
                
                disp('参数验证通过');
            catch e
                isValid = false;
                warning('%s', ['参数验证失败: ' e.message]);
            end
        end
        
        function validateParams(obj, params)
            % validateParams 验证模型参数
            %
            % 输入参数:
            %   params - 模型参数结构体
            
            % 检查必要字段
            required_fields = {'C', 'beta', 'psi', 'delta', 'theta', 'epsilon', 'sigma'};
            for i = 1:length(required_fields)
                if ~isfield(params, required_fields{i})
                    error('参数缺少必要字段: %s', required_fields{i});
                end
            end
            
            % 验证值域
            if params.C <= 0 || floor(params.C) ~= params.C
                error('城市数量必须为正整数');
            end
            
            if params.beta <= 0 || params.beta >= 1
                error('折现因子beta必须在(0,1)范围内');
            end
            
            if params.psi <= 0
                error('跨期替代弹性psi必须为正值');
            end
            
            if params.delta < 0 || params.delta > 1
                error('折旧率delta必须在[0,1]范围内');
            end
            
            if params.theta <= 0
                error('贸易弹性theta必须为正值');
            end
            
            if params.epsilon <= 0
                error('资本替代弹性epsilon必须为正值');
            end
            
            if params.sigma <= 1
                error('商品替代弹性sigma必须大于1');
            end
        end
        
        function validateCityData(obj, city_data, C)
            % validateCityData 验证城市数据
            %
            % 输入参数:
            %   city_data - 城市特征数据结构体
            %   C - 城市数量
            
            % 检查必要字段
            required_fields = {'pop', 'GDP', 'mu', 'K'};
            for i = 1:length(required_fields)
                if ~isfield(city_data, required_fields{i})
                    error('城市数据缺少必要字段: %s', required_fields{i});
                end
            end
            
            % 验证维度
            if length(city_data.pop) ~= C
                error('人口数据维度与城市数量不符');
            end
            
            if length(city_data.GDP) ~= C
                error('GDP数据维度与城市数量不符');
            end
            
            if length(city_data.mu) ~= C
                error('劳动份额数据维度与城市数量不符');
            end
            
            if length(city_data.K) ~= C
                error('资本存量数据维度与城市数量不符');
            end
            
            % 验证值域
            if any(city_data.pop <= 0)
                error('人口数据必须全为正值');
            end
            
            if any(city_data.GDP <= 0)
                error('GDP数据必须全为正值');
            end
            
            if any(city_data.mu <= 0) || any(city_data.mu >= 1)
                error('劳动份额mu必须在(0,1)范围内');
            end
            
            if any(city_data.K < 0)
                error('资本存量必须为非负值');
            end
        end
        
        function validateBilateralData(obj, bilateral_data, C)
            % validateBilateralData 验证双边矩阵数据
            %
            % 输入参数:
            %   bilateral_data - 双边矩阵数据结构体
            %   C - 城市数量
            
            % 检查必要字段
            required_fields = {'trade_flow', 'trade_cost'};
            for i = 1:length(required_fields)
                if ~isfield(bilateral_data, required_fields{i})
                    error('双边数据缺少必要字段: %s', required_fields{i});
                end
            end
            
            % 验证维度
            [r1, c1] = size(bilateral_data.trade_flow);
            if r1 ~= C || c1 ~= C
                warning('贸易流量矩阵维度 %dx%d 与城市数量 %d 不符', r1, c1, C);
            end
            
            [r2, c2] = size(bilateral_data.trade_cost);
            if r2 ~= C || c2 ~= C
                warning('贸易成本矩阵维度 %dx%d 与城市数量 %d 不符', r2, c2, C);
            end
            
            % 验证值域
            if any(bilateral_data.trade_flow(:) < 0)
                error('贸易流量不能为负值');
            end
            
            if any(bilateral_data.trade_cost(:) < 1)
                warning('贸易成本矩阵存在小于1的值，贸易成本应该大于等于1');
            end
            
            % 验证对角线
            min_dim1 = min([C, r1, c1]);
            for i = 1:min_dim1
                if bilateral_data.trade_flow(i,i) <= 0
                    warning('城市 %d 自身贸易流量为零或负值', i);
                end
            end
            
            min_dim2 = min([C, r2, c2]);
            for i = 1:min_dim2
                if abs(bilateral_data.trade_cost(i,i) - 1) > 1e-6
                    warning('城市 %d 自身贸易成本不为1，已自动调整为1', i);
                    bilateral_data.trade_cost(i,i) = 1;
                end
            end
        end
        
        function validatePolicy(obj, policy, C)
            % validatePolicy 验证政策参数
            %
            % 输入参数:
            %   policy - 政策参数结构体
            %   C - 城市数量
            
            % 如果政策为空，直接返回
            if isempty(policy)
                return;
            end
            
            % 验证税收字段
            if isfield(policy, 'tax') && ~isempty(policy.tax)
                if length(policy.tax) ~= C
                    warning('税收向量维度与城市数量不符，将被调整');
                end
            end
            
            % 验证贸易成本变化矩阵
            if isfield(policy, 'tau_change') && ~isempty(policy.tau_change)
                [r, c] = size(policy.tau_change);
                if r ~= C || c ~= C
                    warning('贸易成本变化矩阵维度与城市数量不符，将被调整');
                end
                
                if any(policy.tau_change(:) <= 0)
                    error('贸易成本变化倍数必须为正值');
                end
            end
            
            % 验证时间参数
            if isfield(policy, 'T_announce') && policy.T_announce < 0
                error('政策宣布时期不能为负值');
            end
            
            if isfield(policy, 'T_implement') && policy.T_implement < 0
                error('政策实施时期不能为负值');
            end
            
            % 验证实施期不早于宣布期
            if isfield(policy, 'T_announce') && isfield(policy, 'T_implement') && policy.T_implement < policy.T_announce
                error('政策实施时期不能早于宣布时期');
            end
        end
        
        function validateConsistency(obj, params, city_data, bilateral_data)
            % validateConsistency 验证参数与数据间的一致性
            %
            % 输入参数:
            %   params - 模型参数结构体
            %   city_data - 城市特征数据结构体
            %   bilateral_data - 双边矩阵数据结构体
            
            C = params.C;
            
            % 检查城市数量一致性
            if length(city_data.pop) ~= C
                error('城市数据中的城市数量与参数不符');
            end
            
            % 检查贸易矩阵总值与GDP总和的关系
            % 使用更安全的方式计算贸易总额
            trade_flow_matrix = bilateral_data.trade_flow;
            total_trade = sum(sum(trade_flow_matrix));
            total_gdp = sum(city_data.GDP);
            
            % 通常贸易总额应小于等于GDP总和的2倍（含进出口）
            if total_trade > 2 * total_gdp && total_trade > 0 && total_gdp > 0
                warning('贸易总额与GDP总和比例异常，可能存在数据单位不一致');
            end
            
            % 检查sigma与theta的关系
            if params.sigma ~= params.theta + 1
                warning('商品替代弹性sigma应等于theta+1，检查参数设置');
            end
            
            % 检查资本与GDP比例
            capital_gdp_ratio = sum(city_data.K) / sum(city_data.GDP);
            if capital_gdp_ratio < 1 || capital_gdp_ratio > 10
                warning('资本与GDP总比例为%.2f，超出典型范围[1,10]', capital_gdp_ratio);
            end
        end
    end
end 