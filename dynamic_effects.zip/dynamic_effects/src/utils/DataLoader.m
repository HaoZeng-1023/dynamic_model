classdef DataLoader < handle
    % DataLoader 负责加载和处理模型所需的各类数据
    
    methods
        function [params, city_data, bilateral_data] = loadData(obj, params_file, city_data_file, trade_data_file, trade_cost_file)
            % loadData 加载模型所需的所有数据
            %
            % 输入参数:
            %   params_file - 参数配置文件路径
            %   city_data_file - 城市基础数据文件路径
            %   trade_data_file - 贸易流量数据文件路径
            %   trade_cost_file - 贸易成本矩阵文件路径
            %
            % 输出参数:
            %   params - 模型参数结构体
            %   city_data - 城市特征数据结构体
            %   bilateral_data - 双边矩阵数据结构体
            
            % 加载基本参数
            params = obj.loadParameters(params_file);
            
            % 加载城市数据
            city_data = obj.loadCityData(city_data_file);
            
            % 更新城市数量
            params.C = length(city_data.pop);
            
            % 加载贸易和贸易成本数据
            bilateral_data = obj.loadBilateralData(trade_data_file, trade_cost_file, params.C);
            
            % 保存城市数据引用到参数中（方便后续使用）
            params.city_data = city_data;
        end
        
        function params = loadParameters(obj, file_path)
            % loadParameters 加载模型参数
            %
            % 输入参数:
            %   file_path - 参数文件路径
            %
            % 输出参数:
            %   params - 参数结构体
            
            % 检查文件是否存在
            if ~exist(char(file_path), 'file')
                error('参数文件不存在: %s', file_path);
            end
            
            % 尝试加载JSON格式文件
            try
                % 读取JSON文件
                fid = fopen(char(file_path), 'r');
                raw = fread(fid, inf);
                str = char(raw');
                fclose(fid);
                
                % 解析JSON
                params = jsondecode(str);
            catch
                % 如果JSON解析失败，尝试加载.mat文件
                try
                    data = load(char(file_path));
                    params = data.params;
                catch
                    error('无法解析参数文件: %s', file_path);
                end
            end
            
            % 设置默认参数（如果缺失）
            if ~isfield(params, 'beta')
                params.beta = 0.95;
            end
            if ~isfield(params, 'psi')
                params.psi = 0.5;
            end
            if ~isfield(params, 'delta')
                params.delta = 0.05;
            end
            if ~isfield(params, 'theta')
                params.theta = 5;
            end
            if ~isfield(params, 'epsilon')
                params.epsilon = 4;
            end
            if ~isfield(params, 'sigma')
                params.sigma = params.theta + 1;
            end
            
            % 显示加载的参数
            disp('已加载模型参数:');
            disp(params);
        end
        
        function city_data = loadCityData(obj, file_path)
            % loadCityData 加载城市基础数据
            %
            % 输入参数:
            %   file_path - 城市数据文件路径
            %
            % 输出参数:
            %   city_data - 城市数据结构体
            
            % 检查文件是否存在
            if ~exist(char(file_path), 'file')
                error('城市数据文件不存在: %s', file_path);
            end
            
            % 加载数据
            try
                % 尝试读取CSV文件
                data = readtable(char(file_path));
                
                % 提取列数据
                city_names = data.city_name;
                
                % 检查人口列名
                if ismember('pop', data.Properties.VariableNames)
                    pop = data.pop;
                elseif ismember('population', data.Properties.VariableNames)
                    pop = data.population;
                else
                    error('城市数据文件缺少人口列（pop或population）');
                end
                
                % 检查GDP列名
                if ismember('GDP', data.Properties.VariableNames)
                    gdp = data.GDP;
                elseif ismember('gdp', data.Properties.VariableNames)
                    gdp = data.gdp;
                else
                    error('城市数据文件缺少GDP列（GDP或gdp）');
                end
                
                % 检查劳动份额列名
                if ismember('mu', data.Properties.VariableNames)
                    mu = data.mu;
                elseif ismember('labor_share', data.Properties.VariableNames)
                    mu = data.labor_share;
                else
                    warning('城市数据文件缺少劳动份额列（mu或labor_share），使用默认值0.6');
                    mu = 0.6 * ones(size(pop));
                end
                
                % 检查资本列名
                if ismember('K', data.Properties.VariableNames)
                    K = data.K;
                elseif ismember('capital', data.Properties.VariableNames)
                    K = data.capital;
                else
                    warning('城市数据文件缺少资本列（K或capital），使用GDP的3倍作为估计值');
                    % 假设资本与GDP比例为3:1
                    K = 3 * gdp;
                end
                
            catch e
                error('无法加载城市数据: %s\n错误信息: %s', file_path, e.message);
            end
            
            % 构建输出结构体
            city_data = struct();
            city_data.names = city_names;
            city_data.pop = pop;
            city_data.GDP = gdp;
            city_data.mu = mu;
            city_data.K = K;
            
            disp(['已加载 ', num2str(length(pop)), ' 个城市的数据']);
        end
        
        function bilateral_data = loadBilateralData(obj, trade_file, trade_cost_file, C)
            % loadBilateralData 加载双边矩阵数据
            %
            % 输入参数:
            %   trade_file - 贸易流量文件路径
            %   trade_cost_file - 贸易成本矩阵文件路径
            %   C - 城市数量
            %
            % 输出参数:
            %   bilateral_data - 双边数据结构体
            
            bilateral_data = struct();
            
            % 加载贸易流量矩阵
            if exist(char(trade_file), 'file')
                try
                    % 尝试读取CSV格式
                    trade_data = readmatrix(char(trade_file));
                    bilateral_data.trade_flow = trade_data;
                catch
                    % 尝试读取MAT格式
                    try
                        data = load(char(trade_file));
                        % 检查变量名
                        var_names = fieldnames(data);
                        if ismember('trade_flow', var_names)
                            bilateral_data.trade_flow = data.trade_flow;
                        else
                            % 假设第一个变量是贸易流量
                            bilateral_data.trade_flow = data.(var_names{1});
                        end
                    catch
                        warning('无法加载贸易流量数据，使用单位矩阵代替');
                        bilateral_data.trade_flow = eye(C);
                    end
                end
            else
                warning('贸易流量文件不存在，使用单位矩阵代替');
                bilateral_data.trade_flow = eye(C);
            end
            
            % 加载贸易成本矩阵
            if exist(char(trade_cost_file), 'file')
                try
                    % 尝试读取CSV格式
                    trade_cost_data = readmatrix(char(trade_cost_file));
                    bilateral_data.trade_cost = trade_cost_data;
                catch
                    % 尝试读取MAT格式
                    try
                        data = load(char(trade_cost_file));
                        % 检查变量名
                        var_names = fieldnames(data);
                        if ismember('trade_cost', var_names)
                            bilateral_data.trade_cost = data.trade_cost;
                        else
                            % 假设第一个变量是贸易成本
                            bilateral_data.trade_cost = data.(var_names{1});
                        end
                    catch
                        warning('无法加载贸易成本数据，使用默认贸易成本代替');
                        % 默认贸易成本：对角线为1，非对角线为2
                        bilateral_data.trade_cost = ones(C) + eye(C);
                    end
                end
            else
                warning('贸易成本矩阵文件不存在，使用默认贸易成本代替');
                % 默认贸易成本：对角线为1，非对角线为2
                bilateral_data.trade_cost = ones(C) + eye(C);
            end
            
            % 检查矩阵维度
            [r1, c1] = size(bilateral_data.trade_flow);
            [r2, c2] = size(bilateral_data.trade_cost);
            
            if r1 ~= C || c1 ~= C
                warning('贸易流量矩阵维度不匹配，调整为 %d x %d', C, C);
                % 使用截断或扩展的方式调整矩阵大小
                temp = ones(C, C);
                temp(1:min(r1,C), 1:min(c1,C)) = bilateral_data.trade_flow(1:min(r1,C), 1:min(c1,C));
                bilateral_data.trade_flow = temp;
            end
            
            if r2 ~= C || c2 ~= C
                warning('贸易成本矩阵维度不匹配，调整为 %d x %d', C, C);
                % 使用截断或扩展的方式调整矩阵大小
                temp = ones(C, C) + eye(C);
                temp(1:min(r2,C), 1:min(c2,C)) = bilateral_data.trade_cost(1:min(r2,C), 1:min(c2,C));
                bilateral_data.trade_cost = temp;
            end
            
            % 确保贸易成本矩阵对角线为1（自身无贸易成本）
            for i = 1:C
                bilateral_data.trade_cost(i, i) = 1;
            end
            
            disp('已加载双边数据矩阵');
        end
        
        function policy = loadPolicy(obj, file_path)
            % loadPolicy 加载政策参数
            %
            % 输入参数:
            %   file_path - 政策文件路径
            %
            % 输出参数:
            %   policy - 政策参数结构体
            
            % 检查文件是否存在
            if ~exist(char(file_path), 'file')
                warning('政策文件不存在: %s，使用默认政策', file_path);
                policy = struct();
                policy.tax = [];
                policy.tau_change = [];
                policy.T_announce = 0;
                policy.T_implement = 10;
                return;
            end
            
            % 尝试加载JSON格式文件
            try
                % 读取JSON文件
                fid = fopen(char(file_path), 'r');
                raw = fread(fid, inf);
                str = char(raw');
                fclose(fid);
                
                % 解析JSON
                policy = jsondecode(str);
            catch
                % 如果JSON解析失败，尝试加载.mat文件
                try
                    data = load(char(file_path));
                    policy = data.policy;
                catch
                    warning('无法解析政策文件: %s，使用默认政策', file_path);
                    policy = struct();
                    policy.tax = [];
                    policy.tau_change = [];
                    policy.T_announce = 0;
                    policy.T_implement = 10;
                end
            end
            
            % 显示加载的政策信息
            disp('已加载政策参数:');
            if isfield(policy, 'T_announce')
                disp(['政策宣布时期: ', num2str(policy.T_announce)]);
            end
            if isfield(policy, 'T_implement')
                disp(['政策实施时期: ', num2str(policy.T_implement)]);
            end
        end
    end
end 