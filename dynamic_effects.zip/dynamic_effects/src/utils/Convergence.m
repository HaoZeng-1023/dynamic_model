classdef Convergence < handle
    % Convergence 提供收敛性判断的工具函数
    
    properties (Constant)
        DEFAULT_TOL = 1e-8;   % 默认收敛容差
        DEFAULT_MAX_ITER = 1000;  % 默认最大迭代次数
    end
    
    methods (Static)
        function [converged, iter, error] = checkConvergence(current, previous, tol)
            % checkConvergence 检查收敛性
            %
            % 输入参数:
            %   current - 当前值（向量或矩阵）
            %   previous - 上一轮值（向量或矩阵）
            %   tol - 收敛容差（默认为DEFAULT_TOL）
            %
            % 输出参数:
            %   converged - 是否收敛的逻辑值
            %   iter - 迭代计数器
            %   error - 最大误差
            
            % 设置默认容差
            if nargin < 3
                tol = Convergence.DEFAULT_TOL;
            end
            
            % 计算相对误差
            error = max(abs(current(:) - previous(:))) / (1 + max(abs(previous(:))));
            
            % 判断是否收敛
            converged = (error < tol);
        end
        
        function res = dampenUpdate(current, previous, weight)
            % dampenUpdate 阻尼更新
            %
            % 输入参数:
            %   current - 当前计算值
            %   previous - 上一轮值
            %   weight - 阻尼权重（默认0.5）
            %
            % 输出参数:
            %   res - 阻尼更新后的值
            
            if nargin < 3
                weight = 0.5;
            end
            
            res = weight * previous + (1 - weight) * current;
        end
        
        function lambda = adaptiveDamping(iter, max_iter, lambda_min, lambda_max)
            % adaptiveDamping 自适应阻尼系数
            %
            % 输入参数:
            %   iter - 当前迭代次数
            %   max_iter - 最大迭代次数
            %   lambda_min - 最小阻尼系数（默认0.2）
            %   lambda_max - 最大阻尼系数（默认0.8）
            %
            % 输出参数:
            %   lambda - 自适应阻尼系数
            
            if nargin < 3
                lambda_min = 0.2;
            end
            
            if nargin < 4
                lambda_max = 0.8;
            end
            
            % 随着迭代次数增加，阻尼系数减小（加快收敛）
            lambda = lambda_max - (lambda_max - lambda_min) * min(1, iter / (0.7 * max_iter));
        end
        
        function status = monitorConvergence(iter, error, tol, max_iter, display_freq)
            % monitorConvergence 监控收敛过程
            %
            % 输入参数:
            %   iter - 当前迭代次数
            %   error - 当前误差
            %   tol - 收敛容差
            %   max_iter - 最大迭代次数
            %   display_freq - 显示频率（默认每10次迭代）
            %
            % 输出参数:
            %   status - 收敛状态（0-正常继续，1-已收敛，-1-达到最大迭代）
            
            % 默认参数
            if nargin < 3
                tol = Convergence.DEFAULT_TOL;
            end
            
            if nargin < 4
                max_iter = Convergence.DEFAULT_MAX_ITER;
            end
            
            if nargin < 5
                display_freq = 10;
            end
            
            % 初始状态
            status = 0;
            
            % 判断收敛
            if error < tol
                status = 1;
                disp(['已收敛，迭代次数: ', num2str(iter), '，误差: ', num2str(error)]);
                return;
            end
            
            % 判断最大迭代
            if iter >= max_iter
                status = -1;
                warning('达到最大迭代次数 %d，未收敛，误差: %e', max_iter, error);
                return;
            end
            
            % 周期性显示
            if mod(iter, display_freq) == 0
                disp(['迭代: ', num2str(iter), '/', num2str(max_iter), ...
                      '，误差: ', num2str(error), ...
                      '，收敛阈值: ', num2str(tol)]);
            end
        end
        
        function [J, error] = numericalJacobian(func, x0, h)
            % numericalJacobian 计算数值雅可比矩阵
            %
            % 输入参数:
            %   func - 函数句柄，接受向量输入返回向量输出
            %   x0 - 计算雅可比矩阵的点
            %   h - 扰动步长（默认1e-6）
            %
            % 输出参数:
            %   J - 雅可比矩阵
            %   error - 估算的最大误差
            
            if nargin < 3
                h = 1e-6;
            end
            
            % 原点函数值
            f0 = func(x0);
            
            % 初始化雅可比矩阵
            n = length(x0);
            m = length(f0);
            J = zeros(m, n);
            
            % 前向差分计算雅可比
            for j = 1:n
                x_perturb = x0;
                x_perturb(j) = x_perturb(j) + h;
                f_perturb = func(x_perturb);
                J(:, j) = (f_perturb - f0) / h;
            end
            
            % 估计最大误差（一阶近似）
            error = h/2 * max(abs(J(:)));
        end
    end
end 