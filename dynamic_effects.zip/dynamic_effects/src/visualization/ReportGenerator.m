classdef ReportGenerator < handle
    % ReportGenerator 生成分析报告的类
    %   该类负责将分析结果整合为可读的文本和图表报告
    
    properties
        report_dir = 'results/reports/';  % 报告保存目录
    end
    
    methods
        function generateReport(obj, steady_state, trajectory, welfare, city_data, params, policy)
            % generateReport 生成综合分析报告
            %
            % 输入参数:
            %   steady_state - 稳态结果结构体
            %   trajectory - 转移路径结构体
            %   welfare - 福利结果结构体
            %   city_data - 城市特征数据结构体
            %   params - 模型参数结构体
            %   policy - 政策参数结构体
            
            % 创建保存目录（如果不存在）
            if ~exist(obj.report_dir, 'dir')
                mkdir(obj.report_dir);
            end
            
            % 获取当前时间作为报告标识
            timestamp = datestr(now, 'yyyy-mm-dd_HH-MM');
            report_filename = [obj.report_dir, 'analysis_report_', timestamp, '.html'];
            
            % 生成HTML报告
            fid = fopen(report_filename, 'w');
            
            % 写入HTML头部
            obj.writeHtmlHeader(fid);
            
            % 写入报告正文
            obj.writeReportSummary(fid, welfare, trajectory, params, policy);
            obj.writeParamSection(fid, params, policy);
            obj.writeSteadyStateSection(fid, steady_state, city_data);
            obj.writeDynamicSection(fid, trajectory, city_data);
            obj.writeWelfareSection(fid, welfare, city_data);
            
            % 写入HTML尾部
            obj.writeHtmlFooter(fid);
            
            % 关闭文件
            fclose(fid);
            
            % 生成表格报告
            obj.generateExcelReport(steady_state, trajectory, welfare, city_data, params, timestamp);
            
            fprintf('报告已生成: %s\n', report_filename);
        end
        
        function writeHtmlHeader(obj, fid)
            % writeHtmlHeader 写入HTML报告头部
            %
            % 输入参数:
            %   fid - 文件标识符
            
            fprintf(fid, '<!DOCTYPE html>\n');
            fprintf(fid, '<html lang="zh-CN">\n');
            fprintf(fid, '<head>\n');
            fprintf(fid, '  <meta charset="UTF-8">\n');
            fprintf(fid, '  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n');
            fprintf(fid, '  <title>城市间动态一般均衡模型分析报告</title>\n');
            fprintf(fid, '  <style>\n');
            fprintf(fid, '    body { font-family: Arial, "Microsoft YaHei", sans-serif; line-height: 1.6; margin: 0; padding: 0; color: #333; }\n');
            fprintf(fid, '    .container { max-width: 1200px; margin: 0 auto; padding: 20px; }\n');
            fprintf(fid, '    h1, h2, h3 { color: #0066cc; }\n');
            fprintf(fid, '    table { border-collapse: collapse; width: 100%%; margin-bottom: 20px; }\n');
            fprintf(fid, '    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }\n');
            fprintf(fid, '    th { background-color: #f2f2f2; }\n');
            fprintf(fid, '    .summary { background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin-bottom: 20px; }\n');
            fprintf(fid, '    .chart { text-align: center; margin: 20px 0; }\n');
            fprintf(fid, '    .chart img { max-width: 100%%; height: auto; }\n');
            fprintf(fid, '    .positive { color: green; }\n');
            fprintf(fid, '    .negative { color: red; }\n');
            fprintf(fid, '  </style>\n');
            fprintf(fid, '</head>\n');
            fprintf(fid, '<body>\n');
            fprintf(fid, '  <div class="container">\n');
            fprintf(fid, '    <h1>城市间动态一般均衡模型分析报告</h1>\n');
            fprintf(fid, '    <p>生成时间: %s</p>\n', datestr(now, 'yyyy年mm月dd日 HH:MM:SS'));
        end
        
        function writeHtmlFooter(obj, fid)
            % writeHtmlFooter 写入HTML报告尾部
            %
            % 输入参数:
            %   fid - 文件标识符
            
            fprintf(fid, '  </div>\n');
            fprintf(fid, '</body>\n');
            fprintf(fid, '</html>\n');
        end
        
        function writeReportSummary(obj, fid, welfare, trajectory, params, policy)
            % writeReportSummary 写入报告总结部分
            %
            % 输入参数:
            %   fid - 文件标识符
            %   welfare - 福利结果结构体
            %   trajectory - 转移路径结构体
            %   params - 模型参数结构体
            %   policy - 政策参数结构体
            
            fprintf(fid, '    <div class="summary">\n');
            fprintf(fid, '      <h2>分析摘要</h2>\n');
            
            % 计算总体福利变化
            % 使用默认值
            avg_welfare = 0;
            weighted_avg = 0;
            
            % 尝试获取福利变化值
            if isfield(welfare, 'consumption_equivalent')
                avg_welfare = mean(welfare.consumption_equivalent);
            elseif isfield(welfare, 'total_change')
                avg_welfare = mean(welfare.total_change);
            end
            
            % 尝试获取加权平均值
            if isfield(welfare, 'weighted_avg')
                weighted_avg = welfare.weighted_avg;
            else
                weighted_avg = avg_welfare;
                disp('警告: 未找到weighted_avg字段，使用平均值代替');
            end
            
            % 福利变化的文字描述
            if weighted_avg > 0
                welfare_desc = sprintf('积极（+%.2f%%）', weighted_avg);
                welfare_class = 'positive';
            elseif weighted_avg < 0
                welfare_desc = sprintf('消极（%.2f%%）', weighted_avg);
                welfare_class = 'negative';
            else
                welfare_desc = '中性（0.00%）';
                welfare_class = '';
            end
            
            % 政策描述
            if isfield(policy, 'description')
                policy_desc = policy.description;
            else
                if isfield(policy, 'tau_change') && ~isempty(policy.tau_change)
                    policy_desc = '贸易成本变化政策';
                elseif isfield(policy, 'tax') && ~isempty(policy.tax)
                    policy_desc = '税收政策';
                else
                    policy_desc = '未指定政策';
                end
            end
            
            % 长期GDP变化
            final_period = size(trajectory.GDP, 2);
            initial_gdp_sum = sum(trajectory.GDP(:, 1));
            final_gdp_sum = sum(trajectory.GDP(:, final_period));
            gdp_change = (final_gdp_sum / initial_gdp_sum - 1) * 100;
            
            % GDP变化的文字描述
            if gdp_change > 0
                gdp_desc = sprintf('增加（+%.2f%%）', gdp_change);
                gdp_class = 'positive';
            elseif gdp_change < 0
                gdp_desc = sprintf('减少（%.2f%%）', gdp_change);
                gdp_class = 'negative';
            else
                gdp_desc = '不变（0.00%）';
                gdp_class = '';
            end
            
            % 写入摘要信息
            fprintf(fid, '      <p><strong>政策类型:</strong> %s</p>\n', policy_desc);
            fprintf(fid, '      <p><strong>政策实施时期:</strong> %d</p>\n', policy.T_implement);
            fprintf(fid, '      <p><strong>总体福利影响:</strong> <span class="%s">%s</span></p>\n', welfare_class, welfare_desc);
            fprintf(fid, '      <p><strong>长期GDP变化:</strong> <span class="%s">%s</span></p>\n', gdp_class, gdp_desc);
            % 计算区域不平等影响
            if isfield(welfare, 'consumption_equivalent')
                fprintf(fid, '      <p><strong>区域不平等影响:</strong> 福利变化标准差为 %.2f%%</p>\n', std(welfare.consumption_equivalent));
            elseif isfield(welfare, 'total_change')
                fprintf(fid, '      <p><strong>区域不平等影响:</strong> 福利变化标准差为 %.2f%%</p>\n', std(welfare.total_change));
            else
                fprintf(fid, '      <p><strong>区域不平等影响:</strong> 数据不可用</p>\n');
            end
            fprintf(fid, '    </div>\n');
        end
        
        function writeParamSection(obj, fid, params, policy)
            % writeParamSection 写入参数部分
            %
            % 输入参数:
            %   fid - 文件标识符
            %   params - 模型参数结构体
            %   policy - 政策参数结构体
            
            fprintf(fid, '    <h2>模型参数</h2>\n');
            fprintf(fid, '    <table>\n');
            fprintf(fid, '      <tr><th>参数</th><th>值</th><th>描述</th></tr>\n');
            fprintf(fid, '      <tr><td>C</td><td>%d</td><td>城市数量</td></tr>\n', params.C);
            fprintf(fid, '      <tr><td>&beta;</td><td>%.2f</td><td>折现因子</td></tr>\n', params.beta);
            fprintf(fid, '      <tr><td>&psi;</td><td>%.2f</td><td>跨期替代弹性</td></tr>\n', params.psi);
            fprintf(fid, '      <tr><td>&delta;</td><td>%.2f</td><td>折旧率</td></tr>\n', params.delta);
            fprintf(fid, '      <tr><td>&theta;</td><td>%.2f</td><td>贸易弹性</td></tr>\n', params.theta);
            fprintf(fid, '      <tr><td>&epsilon;</td><td>%.2f</td><td>资本替代弹性</td></tr>\n', params.epsilon);
            fprintf(fid, '      <tr><td>&sigma;</td><td>%.2f</td><td>商品替代弹性</td></tr>\n', params.sigma);
            fprintf(fid, '    </table>\n');
            
            % 政策参数
            fprintf(fid, '    <h3>政策参数</h3>\n');
            fprintf(fid, '    <table>\n');
            fprintf(fid, '      <tr><th>参数</th><th>值</th><th>描述</th></tr>\n');
            
            if isfield(policy, 'T_announce')
                fprintf(fid, '      <tr><td>T_announce</td><td>%d</td><td>政策宣布时期</td></tr>\n', policy.T_announce);
            end
            
            if isfield(policy, 'T_implement')
                fprintf(fid, '      <tr><td>T_implement</td><td>%d</td><td>政策实施时期</td></tr>\n', policy.T_implement);
            end
            
            if isfield(policy, 'tau_change') && ~isempty(policy.tau_change)
                fprintf(fid, '      <tr><td>tau_change</td><td>矩阵 (%dx%d)</td><td>贸易成本变化</td></tr>\n', ...
                    size(policy.tau_change, 1), size(policy.tau_change, 2));
                
                % 显示贸易成本变化的统计信息
                min_tau = min(policy.tau_change(:));
                max_tau = max(policy.tau_change(:));
                mean_tau = mean(policy.tau_change(:));
                fprintf(fid, '      <tr><td>tau_change范围</td><td>[%.3f, %.3f]</td><td>最小值和最大值</td></tr>\n', ...
                    min_tau, max_tau);
                fprintf(fid, '      <tr><td>tau_change均值</td><td>%.3f</td><td>平均贸易成本变化</td></tr>\n', mean_tau);
            end
            
            if isfield(policy, 'tax') && ~isempty(policy.tax)
                fprintf(fid, '      <tr><td>tax</td><td>向量 (%dx1)</td><td>税收政策</td></tr>\n', length(policy.tax));
            end
            
            fprintf(fid, '    </table>\n');
        end
        
        function writeSteadyStateSection(obj, fid, steady_state, city_data)
            % writeSteadyStateSection 写入稳态部分
            %
            % 输入参数:
            %   fid - 文件标识符
            %   steady_state - 稳态结果结构体
            %   city_data - 城市特征数据结构体
            
            fprintf(fid, '    <h2>稳态结果</h2>\n');
            
            % 写入前10个城市的稳态结果
            [~, idx] = sort(city_data.GDP, 'descend');
            top_cities = idx(1:min(10, length(idx)));
            
            fprintf(fid, '    <table>\n');
            fprintf(fid, '      <tr><th>城市</th><th>GDP</th><th>人口</th><th>工资</th><th>资本存量</th><th>财富</th><th>消费</th></tr>\n');
            
            for i = 1:length(top_cities)
                city_idx = top_cities(i);
                fprintf(fid, '      <tr><td>%s</td><td>%.2f</td><td>%.2f</td><td>%.2f</td><td>%.2f</td><td>%.2f</td><td>%.2f</td></tr>\n', ...
                    city_data.names{city_idx}, steady_state.GDP(city_idx), city_data.pop(city_idx), ...
                    steady_state.w(city_idx), steady_state.K(city_idx), steady_state.a(city_idx), steady_state.c(city_idx));
            end
            
            fprintf(fid, '    </table>\n');
            
            % 添加图表占位符
            fprintf(fid, '    <div class="chart">\n');
            fprintf(fid, '      <h3>GDP分布</h3>\n');
            fprintf(fid, '      <img src="../steady_state/gdp_distribution.png" alt="GDP分布图">\n');
            fprintf(fid, '    </div>\n');
        end
        
        function writeDynamicSection(obj, fid, trajectory, city_data)
            % writeDynamicSection 写入动态部分
            %
            % 输入参数:
            %   fid - 文件标识符
            %   trajectory - 转移路径结构体
            %   city_data - 城市特征数据结构体
            
            fprintf(fid, '    <h2>动态转移路径</h2>\n');
            
            % 添加图表
            fprintf(fid, '    <div class="chart">\n');
            fprintf(fid, '      <h3>GDP动态路径</h3>\n');
            fprintf(fid, '      <img src="../dynamics/gdp_path.png" alt="GDP路径图">\n');
            fprintf(fid, '    </div>\n');
            
            fprintf(fid, '    <div class="chart">\n');
            fprintf(fid, '      <h3>消费动态路径</h3>\n');
            fprintf(fid, '      <img src="../dynamics/consumption_path.png" alt="消费路径图">\n');
            fprintf(fid, '    </div>\n');
            
            fprintf(fid, '    <div class="chart">\n');
            fprintf(fid, '      <h3>财富动态路径</h3>\n');
            fprintf(fid, '      <img src="../dynamics/wealth_path.png" alt="财富路径图">\n');
            fprintf(fid, '    </div>\n');
            
            % 显示长期变化率
            fprintf(fid, '    <h3>长期变化率（最终时期相对于初始时期）</h3>\n');
            
            % 计算长期变化率
            final_period = size(trajectory.GDP, 2);
            gdp_change = trajectory.GDP(:, final_period) ./ trajectory.GDP(:, 1) - 1;
            c_change = trajectory.c(:, final_period) ./ trajectory.c(:, 1) - 1;
            a_change = trajectory.a(:, final_period) ./ trajectory.a(:, 1) - 1;
            
            % 按GDP排序选择前10个城市
            [~, idx] = sort(city_data.GDP, 'descend');
            top_cities = idx(1:min(10, length(idx)));
            
            fprintf(fid, '    <table>\n');
            fprintf(fid, '      <tr><th>城市</th><th>GDP变化(%)</th><th>消费变化(%)</th><th>财富变化(%)</th></tr>\n');
            
            for i = 1:length(top_cities)
                city_idx = top_cities(i);
                fprintf(fid, '      <tr><td>%s</td><td class="%s">%.2f%%</td><td class="%s">%.2f%%</td><td class="%s">%.2f%%</td></tr>\n', ...
                    city_data.names{city_idx}, ...
                    obj.iff(gdp_change(city_idx) > 0, 'positive', obj.iff(gdp_change(city_idx) < 0, 'negative', '')), gdp_change(city_idx) * 100, ...
                    obj.iff(c_change(city_idx) > 0, 'positive', obj.iff(c_change(city_idx) < 0, 'negative', '')), c_change(city_idx) * 100, ...
                    obj.iff(a_change(city_idx) > 0, 'positive', obj.iff(a_change(city_idx) < 0, 'negative', '')), a_change(city_idx) * 100);
            end
            
            fprintf(fid, '    </table>\n');
        end
        
        function writeWelfareSection(obj, fid, welfare, city_data)
            % writeWelfareSection 写入福利部分
            %
            % 输入参数:
            %   fid - 文件标识符
            %   welfare - 福利结果结构体
            %   city_data - 城市特征数据结构体
            
            fprintf(fid, '    <h2>福利分析</h2>\n');
            
            % 添加图表
            fprintf(fid, '    <div class="chart">\n');
            fprintf(fid, '      <h3>福利分布地图</h3>\n');
            fprintf(fid, '      <img src="../welfare/welfare_map.png" alt="福利分布地图">\n');
            fprintf(fid, '    </div>\n');
            
            fprintf(fid, '    <div class="chart">\n');
            fprintf(fid, '      <h3>主要城市福利变化</h3>\n');
            fprintf(fid, '      <img src="../welfare/welfare_bar.png" alt="福利柱状图">\n');
            fprintf(fid, '    </div>\n');
            
            % 显示福利变化表格
            fprintf(fid, '    <h3>城市福利变化（消费等价变化）</h3>\n');
            
            % 按福利变化排序
            [sorted_welfare, sort_idx] = sort(welfare.consumption_equivalent, 'descend');
            sorted_cities = sort_idx(1:min(20, length(sort_idx)));
            
            fprintf(fid, '    <table>\n');
            fprintf(fid, '      <tr><th>排名</th><th>城市</th><th>福利变化(%)</th><th>预期效应(%)</th><th>实现效应(%)</th></tr>\n');
            
            for i = 1:length(sorted_cities)
                city_idx = sorted_cities(i);
                
                % 获取预期和实现效应（如果有）
                if isfield(welfare, 'anticipation') && isfield(welfare, 'realization')
                    anticipation = welfare.anticipation(city_idx);
                    realization = welfare.realization(city_idx);
                else
                    anticipation = NaN;
                    realization = NaN;
                end
                
                fprintf(fid, '      <tr><td>%d</td><td>%s</td><td class="%s">%.2f%%</td><td>%.2f%%</td><td>%.2f%%</td></tr>\n', ...
                    i, city_data.names{city_idx}, ...
                    obj.iff(welfare.consumption_equivalent(city_idx) > 0, 'positive', obj.iff(welfare.consumption_equivalent(city_idx) < 0, 'negative', '')), ...
                    welfare.consumption_equivalent(city_idx), ...
                    anticipation, realization);
            end
            
            fprintf(fid, '    </table>\n');
        end
        
        function generateExcelReport(obj, steady_state, trajectory, welfare, city_data, params, timestamp)
            % generateExcelReport 生成Excel格式的报告
            %
            % 输入参数:
            %   steady_state - 稳态结果结构体
            %   trajectory - 转移路径结构体
            %   welfare - 福利结果结构体
            %   city_data - 城市特征数据结构体
            %   params - 模型参数结构体
            %   timestamp - 时间戳字符串
            
            % Excel文件路径
            excel_filename = [obj.report_dir, 'results_', timestamp, '.xlsx'];
            
            % 准备稳态数据
            steady_data = [city_data.names, ...
                           num2cell(city_data.GDP), ...
                           num2cell(city_data.pop), ...
                           num2cell(steady_state.w), ...
                           num2cell(steady_state.r), ...
                           num2cell(steady_state.K), ...
                           num2cell(steady_state.a), ...
                           num2cell(steady_state.c)];
                       
            % 准备福利数据
            welfare_data = [city_data.names, ...
                            num2cell(welfare.consumption_equivalent)];
            
            % 准备动态路径数据 (选择几个关键时期)
            T = size(trajectory.GDP_tilde, 2);
            selected_periods = [1, 10, min(50, T), min(100, T), T];
            periods_labels = arrayfun(@(x) sprintf('T=%d', x), selected_periods, 'UniformOutput', false);
            
            gdp_path_data = cell(params.C, 1 + length(selected_periods));
            for i = 1:params.C
                gdp_path_data{i, 1} = city_data.names{i};
                for j = 1:length(selected_periods)
                    t = selected_periods(j);
                    gdp_path_data{i, j+1} = 100 * trajectory.GDP_tilde(i, t);
                end
            end
            
            % 尝试写入Excel文件
            try
                % 稳态表
                header1 = {'城市', 'GDP', '人口', '工资', '资本租金率', '资本存量', '财富', '消费'};
                writecell(header1, excel_filename, 'Sheet', '稳态结果', 'Range', 'A1');
                writecell(steady_data, excel_filename, 'Sheet', '稳态结果', 'Range', 'A2');
                
                % 福利表
                header2 = {'城市', '消费等价福利变化(%)'};
                writecell(header2, excel_filename, 'Sheet', '福利结果', 'Range', 'A1');
                writecell(welfare_data, excel_filename, 'Sheet', '福利结果', 'Range', 'A2');
                
                % GDP路径表
                header3 = ['城市', periods_labels];
                writecell(header3, excel_filename, 'Sheet', 'GDP路径', 'Range', 'A1');
                writecell(gdp_path_data, excel_filename, 'Sheet', 'GDP路径', 'Range', 'A2');
                
                fprintf('Excel报告已生成: %s\n', excel_filename);
            catch
                warning('无法写入Excel文件。可能是MATLAB版本不支持或缺少权限。');
            end
        end
    end
    
    methods
        function result = iff(obj, condition, true_value, false_value)
            % iff 条件选择辅助函数
            %
            % 输入参数:
            %   condition - 条件
            %   true_value - 条件为真时的值
            %   false_value - 条件为假时的值
            %
            % 输出参数:
            %   result - 结果
            
            if condition
                result = true_value;
            else
                result = false_value;
            end
        end
    end
end 