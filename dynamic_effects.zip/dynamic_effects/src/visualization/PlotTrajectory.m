classdef PlotTrajectory < handle
    % PlotTrajectory 可视化动态转移路径
    %   该类负责绘制各种经济变量随时间的变化图表
    
    properties
        fig_width = 900;   % 图表宽度
        fig_height = 600;  % 图表高度
        line_width = 1.5;  % 线宽
        font_size = 12;    % 字体大小
        line_colors;       % 线条颜色列表
    end
    
    methods
        function obj = PlotTrajectory()
            % PlotTrajectory 构造函数
            
            % 初始化颜色列表
            obj.line_colors = [
                0.0000, 0.4470, 0.7410;  % 蓝色
                0.8500, 0.3250, 0.0980;  % 橙色
                0.9290, 0.6940, 0.1250;  % 黄色
                0.4940, 0.1840, 0.5560;  % 紫色
                0.4660, 0.6740, 0.1880;  % 绿色
                0.3010, 0.7450, 0.9330;  % 浅蓝
                0.6350, 0.0780, 0.1840   % 红色
            ];
        end
        
        function plot(obj, trajectory, city_data)
            % plot 绘制转移路径图表
            %
            % 输入参数:
            %   trajectory - 转移路径结构体
            %   city_data - 城市特征数据结构体
            
            % 绘制各类图表
            obj.plotGDPPath(trajectory, city_data);
            obj.plotConsumptionPath(trajectory, city_data);
            obj.plotCapitalPath(trajectory, city_data);
            obj.plotWealthPath(trajectory, city_data);
            obj.plotFactorPricesPath(trajectory, city_data);
            
            % 保存图表
            saveas(gcf, 'results/dynamics/gdp_path.png');
        end
        
        function plotGDPPath(obj, trajectory, city_data)
            % plotGDPPath 绘制GDP路径
            %
            % 输入参数:
            %   trajectory - 转移路径结构体
            %   city_data - 城市特征数据结构体
            
            figure('Position', [100, 100, obj.fig_width, obj.fig_height]);
            
            % 计算相对于稳态的偏离（百分比）
            GDP_deviation = 100 * trajectory.GDP_tilde;
            
            % 时间轴
            time = trajectory.time;
            
            % 选择前10大城市绘制
            [~, idx] = sort(city_data.GDP, 'descend');
            top_cities = idx(1:min(10, length(idx)));
            
            hold on;
            for i = 1:length(top_cities)
                city_idx = top_cities(i);
                color_idx = mod(i-1, size(obj.line_colors, 1)) + 1;
                
                plot(time, GDP_deviation(city_idx, :), ...
                    'LineWidth', obj.line_width, ...
                    'Color', obj.line_colors(color_idx, :));
            end
            hold off;
            
            % 添加图例
            legend(city_data.names(top_cities), 'Location', 'Best');
            
            % 添加标题和标签
            title('城市GDP动态路径（相对于稳态的百分比偏离）', 'FontSize', obj.font_size+2);
            xlabel('时间（期）', 'FontSize', obj.font_size);
            ylabel('变化百分比(%)', 'FontSize', obj.font_size);
            
            % 设置网格
            grid on;
            
            % 添加零线
            yline(0, 'k--', 'LineWidth', 1);
            
            % 保存图表
            saveas(gcf, 'results/dynamics/gdp_path.png');
        end
        
        function plotConsumptionPath(obj, trajectory, city_data)
            % plotConsumptionPath 绘制消费路径
            %
            % 输入参数:
            %   trajectory - 转移路径结构体
            %   city_data - 城市特征数据结构体
            
            figure('Position', [100, 100, obj.fig_width, obj.fig_height]);
            
            % 计算相对于稳态的偏离（百分比）
            c_deviation = 100 * trajectory.c_tilde;
            
            % 时间轴
            time = trajectory.time;
            
            % 选择前10大城市绘制
            [~, idx] = sort(city_data.GDP, 'descend');
            top_cities = idx(1:min(10, length(idx)));
            
            hold on;
            for i = 1:length(top_cities)
                city_idx = top_cities(i);
                color_idx = mod(i-1, size(obj.line_colors, 1)) + 1;
                
                plot(time, c_deviation(city_idx, :), ...
                    'LineWidth', obj.line_width, ...
                    'Color', obj.line_colors(color_idx, :));
            end
            hold off;
            
            % 添加图例
            legend(city_data.names(top_cities), 'Location', 'Best');
            
            % 添加标题和标签
            title('城市消费动态路径（相对于稳态的百分比偏离）', 'FontSize', obj.font_size+2);
            xlabel('时间（期）', 'FontSize', obj.font_size);
            ylabel('变化百分比(%)', 'FontSize', obj.font_size);
            
            % 设置网格
            grid on;
            
            % 添加零线
            yline(0, 'k--', 'LineWidth', 1);
            
            % 保存图表
            saveas(gcf, 'results/dynamics/consumption_path.png');
        end
        
        function plotCapitalPath(obj, trajectory, city_data)
            % plotCapitalPath 绘制资本路径
            %
            % 输入参数:
            %   trajectory - 转移路径结构体
            %   city_data - 城市特征数据结构体
            
            figure('Position', [100, 100, obj.fig_width, obj.fig_height]);
            
            % 计算相对于稳态的偏离（百分比）
            K_deviation = 100 * trajectory.K_tilde;
            
            % 时间轴
            time = trajectory.time;
            
            % 选择前10大城市绘制
            [~, idx] = sort(city_data.GDP, 'descend');
            top_cities = idx(1:min(10, length(idx)));
            
            hold on;
            for i = 1:length(top_cities)
                city_idx = top_cities(i);
                color_idx = mod(i-1, size(obj.line_colors, 1)) + 1;
                
                plot(time, K_deviation(city_idx, :), ...
                    'LineWidth', obj.line_width, ...
                    'Color', obj.line_colors(color_idx, :));
            end
            hold off;
            
            % 添加图例
            legend(city_data.names(top_cities), 'Location', 'Best');
            
            % 添加标题和标签
            title('城市资本存量动态路径（相对于稳态的百分比偏离）', 'FontSize', obj.font_size+2);
            xlabel('时间（期）', 'FontSize', obj.font_size);
            ylabel('变化百分比(%)', 'FontSize', obj.font_size);
            
            % 设置网格
            grid on;
            
            % 添加零线
            yline(0, 'k--', 'LineWidth', 1);
            
            % 保存图表
            saveas(gcf, 'results/dynamics/capital_path.png');
        end
        
        function plotWealthPath(obj, trajectory, city_data)
            % plotWealthPath 绘制财富路径
            %
            % 输入参数:
            %   trajectory - 转移路径结构体
            %   city_data - 城市特征数据结构体
            
            figure('Position', [100, 100, obj.fig_width, obj.fig_height]);
            
            % 计算相对于稳态的偏离（百分比）
            a_deviation = 100 * trajectory.a_tilde;
            
            % 时间轴
            time = trajectory.time;
            
            % 选择前10大城市绘制
            [~, idx] = sort(city_data.GDP, 'descend');
            top_cities = idx(1:min(10, length(idx)));
            
            hold on;
            for i = 1:length(top_cities)
                city_idx = top_cities(i);
                color_idx = mod(i-1, size(obj.line_colors, 1)) + 1;
                
                plot(time, a_deviation(city_idx, :), ...
                    'LineWidth', obj.line_width, ...
                    'Color', obj.line_colors(color_idx, :));
            end
            hold off;
            
            % 添加图例
            legend(city_data.names(top_cities), 'Location', 'Best');
            
            % 添加标题和标签
            title('城市财富动态路径（相对于稳态的百分比偏离）', 'FontSize', obj.font_size+2);
            xlabel('时间（期）', 'FontSize', obj.font_size);
            ylabel('变化百分比(%)', 'FontSize', obj.font_size);
            
            % 设置网格
            grid on;
            
            % 添加零线
            yline(0, 'k--', 'LineWidth', 1);
            
            % 保存图表
            saveas(gcf, 'results/dynamics/wealth_path.png');
        end
        
        function plotFactorPricesPath(obj, trajectory, city_data)
            % plotFactorPricesPath 绘制要素价格路径
            %
            % 输入参数:
            %   trajectory - 转移路径结构体
            %   city_data - 城市特征数据结构体
            
            % 1. 工资路径
            figure('Position', [100, 100, obj.fig_width, obj.fig_height]);
            
            % 计算相对于稳态的偏离（百分比）
            w_deviation = 100 * trajectory.w_tilde;
            
            % 时间轴
            time = trajectory.time;
            
            % 选择前10大城市绘制
            [~, idx] = sort(city_data.GDP, 'descend');
            top_cities = idx(1:min(10, length(idx)));
            
            hold on;
            for i = 1:length(top_cities)
                city_idx = top_cities(i);
                color_idx = mod(i-1, size(obj.line_colors, 1)) + 1;
                
                plot(time, w_deviation(city_idx, :), ...
                    'LineWidth', obj.line_width, ...
                    'Color', obj.line_colors(color_idx, :));
            end
            hold off;
            
            % 添加图例
            legend(city_data.names(top_cities), 'Location', 'Best');
            
            % 添加标题和标签
            title('城市工资动态路径（相对于稳态的百分比偏离）', 'FontSize', obj.font_size+2);
            xlabel('时间（期）', 'FontSize', obj.font_size);
            ylabel('变化百分比(%)', 'FontSize', obj.font_size);
            
            % 设置网格
            grid on;
            
            % 添加零线
            yline(0, 'k--', 'LineWidth', 1);
            
            % 保存图表
            saveas(gcf, 'results/dynamics/wage_path.png');
            
            % 2. 资本租金率路径
            figure('Position', [100, 100, obj.fig_width, obj.fig_height]);
            
            % 计算相对于稳态的偏离（百分比）
            r_deviation = 100 * trajectory.r_tilde;
            
            hold on;
            for i = 1:length(top_cities)
                city_idx = top_cities(i);
                color_idx = mod(i-1, size(obj.line_colors, 1)) + 1;
                
                plot(time, r_deviation(city_idx, :), ...
                    'LineWidth', obj.line_width, ...
                    'Color', obj.line_colors(color_idx, :));
            end
            hold off;
            
            % 添加图例
            legend(city_data.names(top_cities), 'Location', 'Best');
            
            % 添加标题和标签
            title('城市资本租金率动态路径（相对于稳态的百分比偏离）', 'FontSize', obj.font_size+2);
            xlabel('时间（期）', 'FontSize', obj.font_size);
            ylabel('变化百分比(%)', 'FontSize', obj.font_size);
            
            % 设置网格
            grid on;
            
            % 添加零线
            yline(0, 'k--', 'LineWidth', 1);
            
            % 保存图表
            saveas(gcf, 'results/dynamics/capital_rent_path.png');
        end
        
        function plotAggregateGDP(obj, trajectory)
            % plotAggregateGDP 绘制总体GDP路径
            %
            % 输入参数:
            %   trajectory - 转移路径结构体
            
            figure('Position', [100, 100, obj.fig_width, obj.fig_height]);
            
            % 计算总GDP
            total_GDP = sum(trajectory.GDP, 1);
            total_GDP_ss = sum(trajectory.GDP(:, 1));
            
            % 计算相对于初始值的变化
            gdp_change = total_GDP / total_GDP_ss - 1;
            
            % 绘制总GDP变化
            plot(trajectory.time, 100 * gdp_change, ...
                'LineWidth', obj.line_width+1, ...
                'Color', [0, 0.4470, 0.7410]);
            
            % 添加标题和标签
            title('总体GDP变化（相对于初始值的百分比）', 'FontSize', obj.font_size+2);
            xlabel('时间（期）', 'FontSize', obj.font_size);
            ylabel('变化百分比(%)', 'FontSize', obj.font_size);
            
            % 设置网格
            grid on;
            
            % 添加零线
            yline(0, 'k--', 'LineWidth', 1);
            
            % 保存图表
            saveas(gcf, 'results/dynamics/aggregate_gdp.png');
        end
    end
end 