classdef MapVisualizer < handle
    % MapVisualizer 地图可视化工具类
    %   该类用于在地图上可视化城市数据
    
    properties
        fig_width = 1200;   % 图表宽度
        fig_height = 800;   % 图表高度
        font_size = 12;     % 字体大小
        marker_size = 30;   % 标记大小
        color_map = jet;    % 颜色映射
        has_map_toolbox;    % 是否有地图工具箱
    end
    
    methods
        function obj = MapVisualizer()
            % MapVisualizer 构造函数
            
            % 检查是否有Mapping Toolbox
            obj.has_map_toolbox = license('test', 'map_toolbox');
            
            if ~obj.has_map_toolbox
                warning('未检测到Mapping Toolbox，将使用简化地图显示');
            end
        end
        
        function plotWelfare(obj, welfare, city_data)
            % plotWelfare 绘制福利变化地图
            %
            % 输入参数:
            %   welfare - 福利结果结构体
            %   city_data - 城市特征数据结构体
            
            % 获取福利变化数据
            lambda = welfare.consumption_equivalent;
            
            % 绘制福利地图
            obj.plotMap(lambda, city_data, '消费等价福利变化 (%)', 'results/welfare/welfare_map.png');
            
            % 绘制福利柱状图（按GDP排序的前20个城市）
            obj.plotWelfareBar(lambda, city_data, '消费等价福利变化 (%)', 'results/welfare/welfare_bar.png');
        end
        
        function plotMap(obj, data, city_data, title_text, save_path)
            % plotMap 在地图上绘制数据
            %
            % 输入参数:
            %   data - 要绘制的数据向量
            %   city_data - 城市特征数据结构体
            %   title_text - 图表标题
            %   save_path - 保存路径
            
            figure('Position', [100, 100, obj.fig_width, obj.fig_height]);
            
            % 判断是否有坐标数据
            has_coords = isfield(city_data, 'longitude') && isfield(city_data, 'latitude');
            
            if obj.has_map_toolbox && has_coords
                % 使用Mapping Toolbox绘制地图
                worldmap([min(city_data.latitude)-5, max(city_data.latitude)+5], ...
                        [min(city_data.longitude)-5, max(city_data.longitude)+5]);
                
                % 加载国界线
                load coastlines;
                geoshow(coastlat, coastlon, 'Color', [0.7 0.7 0.7]);
                
                % 绘制城市点
                scatterm(city_data.latitude, city_data.longitude, ...
                    obj.marker_size * sqrt(city_data.pop/max(city_data.pop)), data, 'filled');
                
                % 添加颜色条
                colorbar;
                colormap(obj.color_map);
                
                % 添加标题
                title(title_text, 'FontSize', obj.font_size+4);
                
                % 标注主要城市
                [~, idx] = sort(city_data.GDP, 'descend');
                top_cities = idx(1:min(10, length(idx)));
                
                for i = 1:length(top_cities)
                    city_idx = top_cities(i);
                    textm(city_data.latitude(city_idx), city_data.longitude(city_idx), ...
                        city_data.names{city_idx}, 'FontSize', obj.font_size, 'FontWeight', 'bold');
                end
                
            else
                % 简化版本：使用散点图
                if has_coords
                    % 如果有坐标数据，使用真实坐标
                    scatter(city_data.longitude, city_data.latitude, ...
                        obj.marker_size * sqrt(city_data.pop/max(city_data.pop)), data, 'filled');
                    
                    xlabel('经度', 'FontSize', obj.font_size);
                    ylabel('纬度', 'FontSize', obj.font_size);
                else
                    % 如果没有坐标数据，使用随机位置
                    n = length(data);
                    x = randn(n, 1);
                    y = randn(n, 1);
                    
                    scatter(x, y, obj.marker_size * sqrt(city_data.pop/max(city_data.pop)), data, 'filled');
                    
                    xlabel('相对位置X', 'FontSize', obj.font_size);
                    ylabel('相对位置Y', 'FontSize', obj.font_size);
                    
                    % 标注城市名
                    [~, idx] = sort(city_data.GDP, 'descend');
                    top_cities = idx(1:min(10, length(idx)));
                    
                    for i = 1:length(top_cities)
                        city_idx = top_cities(i);
                        text(x(city_idx), y(city_idx), city_data.names{city_idx}, ...
                            'FontSize', obj.font_size, 'FontWeight', 'bold');
                    end
                end
                
                % 添加颜色条和标题
                colorbar;
                colormap(obj.color_map);
                title(title_text, 'FontSize', obj.font_size+4);
            end
            
            % 保存图表
            saveas(gcf, save_path);
        end
        
        function plotWelfareBar(obj, welfare_data, city_data, title_text, save_path)
            % plotWelfareBar 绘制福利柱状图
            %
            % 输入参数:
            %   welfare_data - 福利数据向量
            %   city_data - 城市特征数据结构体
            %   title_text - 图表标题
            %   save_path - 保存路径
            
            figure('Position', [100, 100, obj.fig_width, obj.fig_height]);
            
            % 按GDP排序选择前20个城市
            [~, idx] = sort(city_data.GDP, 'descend');
            top_cities = idx(1:min(20, length(idx)));
            
            % 排序福利变化（从高到低）
            [sorted_welfare, sort_idx] = sort(welfare_data(top_cities), 'descend');
            sorted_cities = top_cities(sort_idx);
            
            % 绘制柱状图
            bar_h = barh(sorted_welfare);
            
            % 设置颜色
            colormap(obj.color_map);
            bar_colors = obj.color_map(round(linspace(1, size(obj.color_map, 1), length(sorted_welfare))), :);
            for i = 1:length(sorted_welfare)
                bar_h.FaceColor = 'flat';
                bar_h.CData(i,:) = bar_colors(i,:);
            end
            
            % 添加城市名称
            set(gca, 'YTick', 1:length(sorted_cities), 'YTickLabel', city_data.names(sorted_cities));
            
            % 添加标题和标签
            title(title_text, 'FontSize', obj.font_size+4);
            xlabel('福利变化 (%)', 'FontSize', obj.font_size);
            
            % 添加网格线
            grid on;
            
            % 添加零线
            xline(0, 'k--', 'LineWidth', 1.5);
            
            % 保存图表
            saveas(gcf, save_path);
        end
        
        function plotCapitalFlow(obj, B, a, city_data, title_text, save_path)
            % plotCapitalFlow 绘制资本流动图
            %
            % 输入参数:
            %   B - 资本份额矩阵
            %   a - 财富向量
            %   city_data - 城市特征数据结构体
            %   title_text - 图表标题
            %   save_path - 保存路径
            
            % 计算资本流动
            capital_flow = B .* repmat(a', size(B, 1), 1);
            
            % 绘制热力图
            figure('Position', [100, 100, obj.fig_width, obj.fig_height]);
            
            % 按GDP排序选择前15个城市
            [~, idx] = sort(city_data.GDP, 'descend');
            top_cities = idx(1:min(15, length(idx)));
            
            % 提取主要城市间的资本流动
            flow_subset = capital_flow(top_cities, top_cities);
            
            % 绘制热力图
            imagesc(flow_subset);
            colormap(obj.color_map);
            colorbar;
            
            % 设置轴标签
            set(gca, 'XTick', 1:length(top_cities), 'XTickLabel', city_data.names(top_cities), ...
                'YTick', 1:length(top_cities), 'YTickLabel', city_data.names(top_cities));
            
            % 旋转X轴标签以避免重叠
            xtickangle(45);
            
            % 添加标题和标签
            title(title_text, 'FontSize', obj.font_size+4);
            xlabel('资本目的地', 'FontSize', obj.font_size);
            ylabel('资本来源', 'FontSize', obj.font_size);
            
            % 保存图表
            saveas(gcf, save_path);
        end
        
        function plotTradeFlow(obj, S, city_data, title_text, save_path)
            % plotTradeFlow 绘制贸易流动图
            %
            % 输入参数:
            %   S - 贸易份额矩阵
            %   city_data - 城市特征数据结构体
            %   title_text - 图表标题
            %   save_path - 保存路径
            
            % 绘制热力图
            figure('Position', [100, 100, obj.fig_width, obj.fig_height]);
            
            % 按GDP排序选择前15个城市
            [~, idx] = sort(city_data.GDP, 'descend');
            top_cities = idx(1:min(15, length(idx)));
            
            % 提取主要城市间的贸易流动
            trade_subset = S(top_cities, top_cities);
            
            % 绘制热力图
            imagesc(trade_subset);
            colormap(obj.color_map);
            colorbar;
            
            % 设置轴标签
            set(gca, 'XTick', 1:length(top_cities), 'XTickLabel', city_data.names(top_cities), ...
                'YTick', 1:length(top_cities), 'YTickLabel', city_data.names(top_cities));
            
            % 旋转X轴标签以避免重叠
            xtickangle(45);
            
            % 添加标题和标签
            title(title_text, 'FontSize', obj.font_size+4);
            xlabel('商品来源地', 'FontSize', obj.font_size);
            ylabel('商品目的地', 'FontSize', obj.font_size);
            
            % 保存图表
            saveas(gcf, save_path);
        end
    end
end 